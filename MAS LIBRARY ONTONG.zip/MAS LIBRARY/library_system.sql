-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 04, 2026 at 01:55 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.0.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `library_system`
--

-- --------------------------------------------------------

--
-- Table structure for table `books`
--

CREATE TABLE `books` (
  `id` int(11) NOT NULL,
  `book_title` varchar(255) NOT NULL,
  `description` text DEFAULT NULL,
  `category` varchar(100) DEFAULT NULL,
  `status` varchar(20) DEFAULT 'Available'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `books`
--

INSERT INTO `books` (`id`, `book_title`, `description`, `category`, `status`) VALUES
(1, 'ICT Innovation for Industry 4.0 Solutions', 'Information and Communication Technology guide.', NULL, 'Available'),
(2, 'Deep Learning with Python', 'A comprehensive guide to neural networks.', NULL, 'Available'),
(3, 'The Girl From The Sea', 'A story about a young traveler at a crossroads.', NULL, 'Available'),
(4, 'Computer Programming Crash Course', 'Learn the basics of coding quickly.', NULL, 'Available');

-- --------------------------------------------------------

--
-- Table structure for table `book_reviews`
--

CREATE TABLE `book_reviews` (
  `id` int(11) NOT NULL,
  `book_title` varchar(255) DEFAULT NULL,
  `review_content` text DEFAULT NULL,
  `date_submitted` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `book_reviews`
--

INSERT INTO `book_reviews` (`id`, `book_title`, `review_content`, `date_submitted`) VALUES
(1, 'THE PATH NOAH MARA', 'nice', '2026-05-02 22:38:01');

-- --------------------------------------------------------

--
-- Table structure for table `borrowed_books`
--

CREATE TABLE `borrowed_books` (
  `id` int(11) NOT NULL,
  `student_name` varchar(100) DEFAULT NULL,
  `student_id` varchar(50) DEFAULT NULL,
  `book_title` varchar(100) DEFAULT NULL,
  `status` varchar(20) DEFAULT NULL,
  `borrow_date` timestamp NOT NULL DEFAULT current_timestamp(),
  `return_date` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `borrowed_books`
--

INSERT INTO `borrowed_books` (`id`, `student_name`, `student_id`, `book_title`, `status`, `borrow_date`, `return_date`) VALUES
(7, 'LARRA SALINAS', '123', 'THE PATH NOAH MARA', 'Returned', '2026-05-02 16:00:00', '2026-05-03 07:34:12'),
(8, 'salinas mj', '123', 'ICT Innovation for Industry 4.0 Solutions', 'Returned', '2026-05-02 16:00:00', '2026-05-03 07:34:19'),
(9, 'joel ontong', '123', 'THE PATH NOAH MARA', NULL, '2026-05-03 16:00:00', '2026-05-07 16:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `borrow_records`
--

CREATE TABLE `borrow_records` (
  `id` int(11) NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  `book_id` int(11) DEFAULT NULL,
  `borrow_date` datetime DEFAULT current_timestamp(),
  `return_date` datetime DEFAULT NULL,
  `status` varchar(20) DEFAULT 'Borrowed'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `library_logs`
--

CREATE TABLE `library_logs` (
  `id` int(11) NOT NULL,
  `book_title` varchar(255) DEFAULT NULL,
  `status` varchar(50) DEFAULT NULL,
  `date_accessed` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `library_logs`
--

INSERT INTO `library_logs` (`id`, `book_title`, `status`, `date_accessed`) VALUES
(17, 'ICT Innovation', 'ACTIVE', '2026-05-02 16:43:22'),
(18, 'CAN\'T I GO INSTEAD', 'ACTIVE', '2026-05-02 17:35:33'),
(19, 'CAN\'T I GO INSTEAD', 'ACTIVE', '2026-05-02 17:37:47'),
(20, 'THE PATH NOAH MARA', 'Reading', '2026-05-02 17:38:16'),
(21, 'ICT Innovation', 'ACTIVE', '2026-05-02 18:17:54'),
(22, 'CAN\'T I GO INSTEAD', 'ACTIVE', '2026-05-02 18:18:18'),
(23, 'ICT Innovation', 'ACTIVE', '2026-05-02 19:26:13'),
(24, 'ICT Innovation', 'ACTIVE', '2026-05-02 19:51:46'),
(25, 'ICT Innovation', 'ACTIVE', '2026-05-02 20:50:32'),
(26, 'ICT Innovation', 'ACTIVE', '2026-05-02 21:01:08'),
(27, 'Divored Hearts', 'ACTIVE', '2026-05-02 21:19:44'),
(28, 'CAN\'T I GO INSTEAD', 'ACTIVE', '2026-05-02 22:37:38'),
(29, 'THE PATH NOAH MARA', 'Reading', '2026-05-03 06:56:41'),
(30, 'DEEP LEARNING', 'ACTIVE', '2026-05-03 07:21:24'),
(31, 'ICT Innovation', 'ACTIVE', '2026-05-03 07:41:55'),
(32, 'ICT Innovation', 'ACTIVE', '2026-05-03 07:49:20'),
(33, 'ICT Innovation', 'ACTIVE', '2026-05-03 07:51:44'),
(34, 'ICT Innovation', 'ACTIVE', '2026-05-03 07:53:38'),
(35, 'Divored Hearts', 'ACTIVE', '2026-05-03 08:12:25'),
(36, 'ICT Innovation', 'ACTIVE', '2026-05-03 08:17:18'),
(37, 'DEEP LEARNING', 'ACTIVE', '2026-05-03 08:17:22'),
(38, 'MEDIA & SOCIETY', 'ACTIVE', '2026-05-03 08:17:25'),
(39, 'DEEP LEARNING', 'ACTIVE', '2026-05-03 08:17:28'),
(40, 'COMPUTER PROGRAMMING', 'ACTIVE', '2026-05-03 08:17:32'),
(41, 'PYTHON PROGRAMMING', 'ACTIVE', '2026-05-03 08:17:36'),
(42, 'DEEP LEARNING', 'ACTIVE', '2026-05-03 08:17:40'),
(43, 'DEEP LEARNING', 'ACTIVE', '2026-05-03 08:17:44'),
(44, 'THE PATH NOAH MARA', 'Reading', '2026-05-03 08:17:51'),
(45, 'THE PATH NOAH MARA', 'Reading', '2026-05-03 08:33:35'),
(46, 'DEEP LEARNING', 'ACTIVE', '2026-05-03 08:33:39'),
(47, 'MEDIA & SOCIETY', 'ACTIVE', '2026-05-03 08:33:41'),
(48, 'DEEP LEARNING', 'ACTIVE', '2026-05-03 08:33:45'),
(49, 'COMPUTER PROGRAMMING', 'ACTIVE', '2026-05-03 08:33:48'),
(50, 'PYTHON PROGRAMMING', 'ACTIVE', '2026-05-03 08:33:52'),
(51, 'DEEP LEARNING', 'ACTIVE', '2026-05-03 08:33:56'),
(52, 'DEEP LEARNING', 'ACTIVE', '2026-05-03 08:33:59'),
(53, 'CAN\'T I GO INSTEAD', 'ACTIVE', '2026-05-03 08:34:05'),
(54, 'DEEP LEARNING', 'ACTIVE', '2026-05-03 08:34:08'),
(55, 'MEDIA & SOCIETY', 'ACTIVE', '2026-05-03 08:34:11'),
(56, 'DEEP LEARNING', 'ACTIVE', '2026-05-03 08:34:14'),
(57, 'COMPUTER PROGRAMMING', 'ACTIVE', '2026-05-03 08:34:17'),
(58, 'PYTHON PROGRAMMING', 'ACTIVE', '2026-05-03 08:34:21'),
(59, 'DEEP LEARNING', 'ACTIVE', '2026-05-03 08:34:25'),
(60, 'DEEP LEARNING', 'ACTIVE', '2026-05-03 08:34:28'),
(61, 'Divored Hearts', 'ACTIVE', '2026-05-03 08:34:34'),
(62, 'DEEP LEARNING', 'ACTIVE', '2026-05-03 08:34:38'),
(63, 'MEDIA & SOCIETY', 'ACTIVE', '2026-05-03 08:34:43'),
(64, 'DEEP LEARNING', 'ACTIVE', '2026-05-03 08:34:46'),
(65, 'COMPUTER PROGRAMMING', 'ACTIVE', '2026-05-03 08:34:49'),
(66, 'DEEP LEARNING', 'ACTIVE', '2026-05-03 08:35:14'),
(67, 'MEDIA & SOCIETY', 'ACTIVE', '2026-05-03 08:35:23'),
(68, 'DEEP LEARNING', 'ACTIVE', '2026-05-03 08:35:28'),
(69, 'ICT Innovation', 'ACTIVE', '2026-05-03 09:24:14'),
(70, 'ICT Innovation', 'ACTIVE', '2026-05-03 09:25:00'),
(71, 'ICT Innovation', 'ACTIVE', '2026-05-03 09:25:39'),
(72, 'DEEP LEARNING', 'ACTIVE', '2026-05-03 09:25:43'),
(73, 'Deathly Fate', 'ACTIVE', '2026-05-03 09:26:01'),
(74, 'THE PATH NOAH MARA', 'Reading', '2026-05-03 09:29:58'),
(75, 'Divored Hearts', 'ACTIVE', '2026-05-03 09:37:05'),
(76, 'ICT Innovation', 'ACTIVE', '2026-05-03 09:37:46'),
(77, 'ICT Innovation', 'ACTIVE', '2026-05-03 09:51:30'),
(78, 'ICT Innovation', 'ACTIVE', '2026-05-03 09:54:26'),
(79, 'DEEP LEARNING', 'ACTIVE', '2026-05-03 09:54:39'),
(80, 'Divored Hearts', 'ACTIVE', '2026-05-03 09:54:54'),
(81, 'Divored Hearts', 'ACTIVE', '2026-05-03 09:55:24'),
(82, 'ICT Innovation', 'ACTIVE', '2026-05-03 10:07:06'),
(83, 'DEEP LEARNING', 'ACTIVE', '2026-05-03 10:07:08'),
(84, 'MEDIA & SOCIETY', 'ACTIVE', '2026-05-03 10:07:11'),
(85, 'DEEP LEARNING', 'ACTIVE', '2026-05-03 10:07:12'),
(86, 'COMPUTER PROGRAMMING', 'ACTIVE', '2026-05-03 10:07:15'),
(87, 'PYTHON PROGRAMMING', 'ACTIVE', '2026-05-03 10:07:17'),
(88, 'DEEP LEARNING', 'ACTIVE', '2026-05-03 10:07:20'),
(89, 'DEEP LEARNING', 'ACTIVE', '2026-05-03 10:07:22'),
(90, 'THE PATH NOAH MARA', 'Reading', '2026-05-03 10:07:27'),
(91, 'DEEP LEARNING', 'ACTIVE', '2026-05-03 10:07:30'),
(92, 'MEDIA & SOCIETY', 'ACTIVE', '2026-05-03 10:07:32'),
(93, 'DEEP LEARNING', 'ACTIVE', '2026-05-03 10:07:33'),
(94, 'COMPUTER PROGRAMMING', 'ACTIVE', '2026-05-03 10:07:36'),
(95, 'PYTHON PROGRAMMING', 'ACTIVE', '2026-05-03 10:07:39'),
(96, 'DEEP LEARNING', 'ACTIVE', '2026-05-03 10:07:41'),
(97, 'DEEP LEARNING', 'ACTIVE', '2026-05-03 10:07:44'),
(98, 'CAN\'T I GO INSTEAD', 'ACTIVE', '2026-05-03 10:07:47'),
(99, 'DEEP LEARNING', 'ACTIVE', '2026-05-03 10:07:50'),
(100, 'MEDIA & SOCIETY', 'ACTIVE', '2026-05-03 10:07:52'),
(101, 'DEEP LEARNING', 'ACTIVE', '2026-05-03 10:07:55'),
(102, 'COMPUTER PROGRAMMING', 'ACTIVE', '2026-05-03 10:07:57'),
(103, 'PYTHON PROGRAMMING', 'ACTIVE', '2026-05-03 10:08:00'),
(104, 'DEEP LEARNING', 'ACTIVE', '2026-05-03 10:08:02'),
(105, 'DEEP LEARNING', 'ACTIVE', '2026-05-03 10:08:04'),
(106, 'ICT Innovation', 'ACTIVE', '2026-05-03 13:20:55'),
(107, 'DEEP LEARNING', 'ACTIVE', '2026-05-03 13:21:09'),
(108, 'MEDIA & SOCIETY', 'ACTIVE', '2026-05-03 13:21:12'),
(109, 'COMPUTER PROGRAMMING', 'ACTIVE', '2026-05-03 13:21:14'),
(110, 'THE PATH NOAH MARA', 'Reading', '2026-05-03 13:42:29'),
(111, 'Divored Hearts', 'ACTIVE', '2026-05-03 13:43:27');

-- --------------------------------------------------------

--
-- Table structure for table `returned_books`
--

CREATE TABLE `returned_books` (
  `id` int(11) NOT NULL,
  `student_name` varchar(100) DEFAULT NULL,
  `book_title` varchar(100) DEFAULT NULL,
  `return_date` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `returned_books`
--

INSERT INTO `returned_books` (`id`, `student_name`, `book_title`, `return_date`) VALUES
(1, 'MARIJANE', 'ICT Innovation for Industry 4.0 Solutions', '2026-05-02 21:40:37'),
(2, 'DSS', 'ICT INNOVATION', '2026-05-02 21:40:44'),
(3, 'archie ', 'ICT Innovation for Industry 4.0 Solutions', '2026-05-02 21:40:50'),
(4, 'wee ree', 'THE PATH NOAH MARA', '2026-05-03 06:25:53'),
(5, 'bautista', 'THE PATH NOAH MARA', '2026-05-03 06:25:59'),
(6, 'eeee', 'ICT Innovation for Industry 4.0 Solutions', '2026-05-03 06:26:08');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `first_name` varchar(100) DEFAULT NULL,
  `last_name` varchar(100) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `password` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `first_name`, `last_name`, `email`, `password`) VALUES
(1, 'marijane', 'marijane@gmail.com', '123', ''),
(2, 'sss', 'sss', '123', ''),
(3, 'aaa', 'aaa', '123', ''),
(4, 'marijane', 'marijane', 'wee', ''),
(6, 'maa', 'maa', 'aaa', ''),
(8, 'WW', 'WW', 'WW', ''),
(10, 'www', 'www', 'www', ''),
(14, 'QQQ', 'QQQ', 'QQQ', ''),
(16, 'marijaneontong', 'marijaneontong@gmail.com', 'marijane', ''),
(17, 'yy', 'yy', 'yy', ''),
(18, 'ss', 'ss', 'ss', ''),
(21, 'zz', 'zz', 'zz', ''),
(22, 'ee', 'ee', 'ee', ''),
(23, 'archie', 'archie@gmail.com', 'aaa', ''),
(24, 'ticaro', 'ticaro@gmail.com', 'eee', ''),
(25, 'iigjvt', 'hh', 'hh', ''),
(26, 'stifany', 'stifany@gmail.com', 'qqq', ''),
(28, 'QQ', 'QQ', 'QQ', ''),
(30, 'MARIJANE', '@GMAIL.COM', 'ONTONG', ''),
(31, NULL, NULL, 'archie@gmail.com', ''),
(32, NULL, NULL, 'eeee', ''),
(33, NULL, NULL, 'bautista@gmail.com', ''),
(34, NULL, NULL, 'STEP@GMAIL.COM', ''),
(35, 'rere', '', 'rere@ggmail.com', 'rere'),
(36, 'sesa', 'sasa', 'sesa@gmail.com', 'sesa'),
(37, 'wee', 'ree', 'weeree@gmail.com', 'weeree'),
(38, 'LARRA', 'SALINAS', 'LARRA@GMAIL.COM', 'LARRA'),
(42, 'salinas', 'mj', 'salinasmj@gmail.com', '123'),
(44, 'maxrill', 'jay', 'maxrill jay', '123'),
(45, 'joel', 'ontong', 'joelontong@gmail.com', '234');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `books`
--
ALTER TABLE `books`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `book_reviews`
--
ALTER TABLE `book_reviews`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `borrowed_books`
--
ALTER TABLE `borrowed_books`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `borrow_records`
--
ALTER TABLE `borrow_records`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `book_id` (`book_id`);

--
-- Indexes for table `library_logs`
--
ALTER TABLE `library_logs`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `returned_books`
--
ALTER TABLE `returned_books`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`last_name`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `books`
--
ALTER TABLE `books`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `book_reviews`
--
ALTER TABLE `book_reviews`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `borrowed_books`
--
ALTER TABLE `borrowed_books`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `borrow_records`
--
ALTER TABLE `borrow_records`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `library_logs`
--
ALTER TABLE `library_logs`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=112;

--
-- AUTO_INCREMENT for table `returned_books`
--
ALTER TABLE `returned_books`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=46;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `borrow_records`
--
ALTER TABLE `borrow_records`
  ADD CONSTRAINT `borrow_records_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`),
  ADD CONSTRAINT `borrow_records_ibfk_2` FOREIGN KEY (`book_id`) REFERENCES `books` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
