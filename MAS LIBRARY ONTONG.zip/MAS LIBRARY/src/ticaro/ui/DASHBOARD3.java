package ticaro.ui;
import MAIN.ADMIN;
import TEST.BORROWED_BOOKS;
import TEST.FirstPanel;
import TEST.FourthPanel;
import TEST.SecondPanel;
import TEST.ThirdPanel;
import TEST.Student;
import TEST.pnlNewArrivals;
import java.awt.CardLayout;
import java.awt.GridLayout;
import javax.swing.JFrame;
import javax.swing.table.DefaultTableModel;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Connection;
import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;


/**
 *
 * @author Alethea Jae
 */
public class DASHBOARD3 extends javax.swing.JFrame {
    
    private static final java.util.logging.Logger logger = java.util.logging.Logger.getLogger(DASHBOARD3.class.getName());
public String globalStudentID;
   FirstPanel a = new FirstPanel();
    SecondPanel b = new SecondPanel();
    ThirdPanel c = new ThirdPanel();
    FourthPanel d = new FourthPanel();
   BORROWED_BOOKS e; 
  Student f;
   pnlNewArrivals g = new pnlNewArrivals();
   
    
    private final String loggedInUserId;

public DASHBOARD3(String userId) {
    initComponents(); // ONLY CALL THIS ONCE
    this.loggedInUserId = userId;
    this.globalStudentID = String.valueOf(userId); 
    this.setExtendedState(JFrame.MAXIMIZED_BOTH);
    
    // Initialize your panels here
    this.f = new Student(globalStudentID); 
    this.e = new BORROWED_BOOKS(globalStudentID);

    // Add them to your layered pane
    main.add(a, "Education");
    main.add(b, "Romance");
    main.add(c, "Literature");
    main.add(d, "Drama");
    main.add(e, "Borrowed");
    main.add(f, "Student");
    main.add(g, "NewArrivals");

    btnAdminSettings.setVisible(false);
    hideAllPanels(); 
    this.setExtendedState(JFrame.MAXIMIZED_BOTH);
}



private void hideAllPanels() {
    a.setVisible(false);
    b.setVisible(false);
    c.setVisible(false);
    d.setVisible(false);
    e.setVisible(false); // Borrowed Books
    f.setVisible(false); // Student Profile
    g.setVisible(false);
}
    
      
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        educbtn = new javax.swing.JButton();
        romancebtn = new javax.swing.JButton();
        literaturebtn = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        btnAdminSettings = new javax.swing.JButton();
        dramabtn = new javax.swing.JButton();
        BTNLOGOUT = new javax.swing.JButton();
        myaccountbtn = new javax.swing.JButton();
        newbooksbtn = new javax.swing.JButton();
        main = new javax.swing.JLayeredPane();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setBackground(new java.awt.Color(255, 255, 255));
        jPanel1.setMinimumSize(new java.awt.Dimension(190, 100));
        jPanel1.setPreferredSize(new java.awt.Dimension(170, 644));
        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        educbtn.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        educbtn.setText("EDUCATION");
        educbtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                educbtnActionPerformed(evt);
            }
        });
        jPanel1.add(educbtn, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 270, 131, -1));

        romancebtn.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        romancebtn.setText("ROMANCE");
        romancebtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                romancebtnActionPerformed(evt);
            }
        });
        jPanel1.add(romancebtn, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 300, 131, -1));

        literaturebtn.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        literaturebtn.setText("LITERATURE");
        literaturebtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                literaturebtnActionPerformed(evt);
            }
        });
        jPanel1.add(literaturebtn, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 330, 131, -1));

        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/1library..png"))); // NOI18N
        jPanel1.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(6, 18, -1, -1));

        jLabel2.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        jLabel2.setText("STUDENT PROFILE");
        jPanel1.add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(23, 214, -1, -1));

        btnAdminSettings.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        btnAdminSettings.setText("ADMIN SETTINGS");
        btnAdminSettings.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnAdminSettingsActionPerformed(evt);
            }
        });
        jPanel1.add(btnAdminSettings, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 540, 140, -1));

        dramabtn.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        dramabtn.setText("DRAMA/ACTION");
        dramabtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                dramabtnActionPerformed(evt);
            }
        });
        jPanel1.add(dramabtn, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 360, 131, -1));

        BTNLOGOUT.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        BTNLOGOUT.setText("LOG OUT");
        BTNLOGOUT.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BTNLOGOUTActionPerformed(evt);
            }
        });
        jPanel1.add(BTNLOGOUT, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 570, 140, -1));

        myaccountbtn.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        myaccountbtn.setText("MY ACCOUNT");
        myaccountbtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                myaccountbtnActionPerformed(evt);
            }
        });
        jPanel1.add(myaccountbtn, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 470, 140, -1));

        newbooksbtn.setFont(new java.awt.Font("Segoe UI Historic", 1, 12)); // NOI18N
        newbooksbtn.setText("NEW BOOKS");
        newbooksbtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                newbooksbtnActionPerformed(evt);
            }
        });
        jPanel1.add(newbooksbtn, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 390, 130, -1));

        getContentPane().add(jPanel1, java.awt.BorderLayout.LINE_START);

        main.setBackground(new java.awt.Color(255, 255, 255));
        main.setPreferredSize(new java.awt.Dimension(1200, 800));
        main.setLayout(new java.awt.CardLayout());
        getContentPane().add(main, java.awt.BorderLayout.CENTER);

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void literaturebtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_literaturebtnActionPerformed
        a.setVisible(false);
        b.setVisible(false);
        c.setVisible(true);
        d.setVisible(false);
    }//GEN-LAST:event_literaturebtnActionPerformed

    private void romancebtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_romancebtnActionPerformed
        a.setVisible(false);
        b.setVisible(true);
        c.setVisible(false);
        d.setVisible(false);
    }//GEN-LAST:event_romancebtnActionPerformed

    private void educbtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_educbtnActionPerformed
   CardLayout cl = (CardLayout)(main.getLayout());
    cl.show(main, "Education");

    }//GEN-LAST:event_educbtnActionPerformed

    private void btnAdminSettingsActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnAdminSettingsActionPerformed
       
    ADMIN adminPage = new ADMIN(); 
    adminPage.setVisible(true); 
    
    this.dispose();
   
    }//GEN-LAST:event_btnAdminSettingsActionPerformed

    private void dramabtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_dramabtnActionPerformed
     a.setVisible(false);
        b.setVisible(false);
        c.setVisible(false);
        d.setVisible(true );
    }//GEN-LAST:event_dramabtnActionPerformed

    private void BTNLOGOUTActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BTNLOGOUTActionPerformed
     int confirm = javax.swing.JOptionPane.showConfirmDialog(
        null,
        "Are you sure you want to log out of the M.A.S Library System?",
        "Logout",
        javax.swing.JOptionPane.YES_NO_OPTION
    );

    if (confirm == javax.swing.JOptionPane.YES_OPTION) {
        dispose(); 
       
        new LOGIN().setVisible(true); 
    }
    }//GEN-LAST:event_BTNLOGOUTActionPerformed

    private void myaccountbtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_myaccountbtnActionPerformed
f.showBorrowedBooks(globalStudentID);   
    f.loadFavoriteBooks(globalStudentID);  
    f.loadReadBooks(globalStudentID);      
    f.loadNotifications(globalStudentID); 
    f.revalidate();
f.repaint();
    
    // 2. Switch the view using CardLayout
    CardLayout cl = (CardLayout)(main.getLayout());
    cl.show(main, "Student");
    
    // 3. Optional: Refresh UI to ensure tables draw correctly
    main.revalidate();
    main.repaint();
    
    }//GEN-LAST:event_myaccountbtnActionPerformed

    private void newbooksbtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_newbooksbtnActionPerformed
  g.loadBooksFromDatabase(); 
    
    // 2. Use CardLayout to show the "NewArrivals" panel (which you named 'g')
    java.awt.CardLayout cl = (java.awt.CardLayout)(main.getLayout());
    cl.show(main, "NewArrivals");
    
    // 3. Refresh just in case
    main.revalidate();
    main.repaint();
    }//GEN-LAST:event_newbooksbtnActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ReflectiveOperationException | javax.swing.UnsupportedLookAndFeelException ex) {
            logger.log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
      java.awt.EventQueue.invokeLater(() -> new DASHBOARD3("1").setVisible(true));
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton BTNLOGOUT;
    public javax.swing.JButton btnAdminSettings;
    private javax.swing.JButton dramabtn;
    private javax.swing.JButton educbtn;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    public javax.swing.JPanel jPanel1;
    private javax.swing.JButton literaturebtn;
    private javax.swing.JLayeredPane main;
    private javax.swing.JButton myaccountbtn;
    private javax.swing.JButton newbooksbtn;
    private javax.swing.JButton romancebtn;
    // End of variables declaration//GEN-END:variables

   
 
}
  


