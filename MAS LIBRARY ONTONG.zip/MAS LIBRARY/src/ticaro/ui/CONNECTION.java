package ticaro.ui;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

public class CONNECTION {
    public static Connection getConnection() {
    try {
        return DriverManager.getConnection(
            "jdbc:mysql://localhost:3306/library_system",
            "root",
            ""
        );
    } catch (Exception e) {
        e.printStackTrace();
        return null;
    }
}
}


