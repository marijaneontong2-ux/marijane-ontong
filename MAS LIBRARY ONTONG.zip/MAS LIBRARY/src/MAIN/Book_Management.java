package MAIN;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.*;
import java.io.File;
import java.sql.*;
import javax.swing.JFileChooser;
import javax.swing.ImageIcon;
import java.awt.Image;
import ticaro.ui.CONNECTION;

/**
 * @author MARY GANE
 */
public class Book_Management extends javax.swing.JFrame {

    private static final java.util.logging.Logger logger = java.util.logging.Logger.getLogger(Book_Management.class.getName());
    
   
    private final String url = "jdbc:mysql://localhost:3306/library_system";
    private final String user = "root";
    private final String pass = "";

    public Book_Management() { 
    initComponents();      
    loadBooks();          
}

public void loadBooks() {
    DefaultTableModel model = (DefaultTableModel) tblBooks.getModel(); 
    model.setRowCount(0); 

    try (Connection con = CONNECTION.getConnection()) {
        // --- PASTE THE NEW SQL QUERY BELOW ---
        String sql = "SELECT * FROM books WHERE is_visible = 1"; 
        // -------------------------------------

        PreparedStatement pst = con.prepareStatement(sql);
        ResultSet rs = pst.executeQuery();

        while (rs.next()) {
            String id = rs.getString("id"); 
            String title = rs.getString("book_title");
            String category = rs.getString("category");
            String status = rs.getString("status");

            model.addRow(new Object[]{id, title, "N/A", category, status});
        }
    } catch (Exception e) {
        System.out.println("Error loading books: " + e.getMessage());
    }
}
    // <editor-fold defaultstate="collapsed" desc="Generated Code">
    // ... (Keep your existing layout code here verbatim from image_02d898.png) ...
    // Ensure you use: btnUpdateBook.addActionListener(evt -> btnUpdateBookActionPerformed(evt));

    // </editor-fold>
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jPanel3 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        txtBookId = new javax.swing.JTextField();
        txtTitle = new javax.swing.JTextField();
        txtAuthor = new javax.swing.JTextField();
        comboStatus = new javax.swing.JComboBox<>();
        comboCategory = new javax.swing.JComboBox<>();
        REFRESH_BTN = new javax.swing.JButton();
        jScrollPane2 = new javax.swing.JScrollPane();
        txtDescription = new javax.swing.JTextArea();
        btnBrowse = new javax.swing.JButton();
        txtFilePath = new javax.swing.JTextField();
        jPanel2 = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        jButton1 = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        tblBooks = new javax.swing.JTable();
        jPanel4 = new javax.swing.JPanel();
        btnclearbook = new javax.swing.JButton();
        btnUpdateBook = new javax.swing.JButton();
        btnAddBook = new javax.swing.JButton();
        btnDeleteBook = new javax.swing.JButton();
        lblPreview = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel1.setBackground(new java.awt.Color(255, 255, 255));
        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel3.setBackground(new java.awt.Color(51, 51, 51));
        jPanel3.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel1.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 255, 255));
        jLabel1.setText("AVAILABILITY STATUS:");
        jPanel3.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 690, 200, -1));

        jLabel5.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jLabel5.setForeground(new java.awt.Color(255, 255, 255));
        jLabel5.setText("BOOK ID:");
        jPanel3.add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 120, 80, -1));

        jLabel6.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jLabel6.setForeground(new java.awt.Color(255, 255, 255));
        jLabel6.setText("BOOK TITLE:");
        jPanel3.add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 170, 100, -1));

        jLabel7.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jLabel7.setForeground(new java.awt.Color(255, 255, 255));
        jLabel7.setText("AUTHOR:");
        jPanel3.add(jLabel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 210, 80, -1));

        jLabel8.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jLabel8.setForeground(new java.awt.Color(255, 255, 255));
        jLabel8.setText("CATEGORY:");
        jPanel3.add(jLabel8, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 660, 90, -1));
        jPanel3.add(txtBookId, new org.netbeans.lib.awtextra.AbsoluteConstraints(120, 110, 230, 30));
        jPanel3.add(txtTitle, new org.netbeans.lib.awtextra.AbsoluteConstraints(120, 160, 230, 30));
        jPanel3.add(txtAuthor, new org.netbeans.lib.awtextra.AbsoluteConstraints(120, 200, 230, 30));

        comboStatus.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        comboStatus.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "BORROWED ", "AVAILABLE", " " }));
        jPanel3.add(comboStatus, new org.netbeans.lib.awtextra.AbsoluteConstraints(190, 690, 150, -1));

        comboCategory.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        comboCategory.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "EDUCATION", "LITERATURE", "ROMANCE", "DRAMA", " " }));
        jPanel3.add(comboCategory, new org.netbeans.lib.awtextra.AbsoluteConstraints(120, 660, 220, -1));

        REFRESH_BTN.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        REFRESH_BTN.setText("REFRESH");
        REFRESH_BTN.addActionListener(this::REFRESH_BTNActionPerformed);
        jPanel3.add(REFRESH_BTN, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 10, 110, 40));

        txtDescription.setColumns(20);
        txtDescription.setRows(5);
        jScrollPane2.setViewportView(txtDescription);

        jPanel3.add(jScrollPane2, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 260, 330, 160));

        btnBrowse.addActionListener(this::btnBrowseActionPerformed);
        jPanel3.add(btnBrowse, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 450, -1, 30));
        jPanel3.add(txtFilePath, new org.netbeans.lib.awtextra.AbsoluteConstraints(120, 450, 170, 170));

        jPanel1.add(jPanel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 10, 380, 720));

        jPanel2.setBackground(new java.awt.Color(0, 0, 0));
        jPanel2.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel2.setFont(new java.awt.Font("Times New Roman", 1, 24)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(255, 255, 255));
        jLabel2.setText("BOOK MANAGEMENT SYSTEM");
        jPanel2.add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(380, 20, 370, -1));

        jButton1.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        jButton1.setText("BACK");
        jButton1.addActionListener(this::jButton1ActionPerformed);
        jPanel2.add(jButton1, new org.netbeans.lib.awtextra.AbsoluteConstraints(910, 20, 90, 30));

        jPanel1.add(jPanel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 1030, 70));

        tblBooks.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        tblBooks.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null}
            },
            new String [] {
                "ID", "BOOK TITLE", "AUTHOR", "CATEGORY", "STATUS"
            }
        ));
        tblBooks.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tblBooksMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(tblBooks);

        jPanel1.add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(380, 70, 650, 420));

        jPanel4.setBackground(new java.awt.Color(51, 51, 51));
        jPanel4.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        btnclearbook.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        btnclearbook.setText("CLEAR BOOK");
        btnclearbook.addActionListener(this::btnclearbookActionPerformed);
        jPanel4.add(btnclearbook, new org.netbeans.lib.awtextra.AbsoluteConstraints(320, 70, 120, 60));

        btnUpdateBook.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        btnUpdateBook.setText("UPDATE BOOK");
        btnUpdateBook.addActionListener(this::btnUpdateBookActionPerformed);
        jPanel4.add(btnUpdateBook, new org.netbeans.lib.awtextra.AbsoluteConstraints(320, 150, 120, 60));

        btnAddBook.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        btnAddBook.setText("ADD BOOK");
        btnAddBook.addActionListener(this::btnAddBookActionPerformed);
        jPanel4.add(btnAddBook, new org.netbeans.lib.awtextra.AbsoluteConstraints(490, 70, 120, 60));

        btnDeleteBook.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        btnDeleteBook.setText("DELETE BOOK");
        btnDeleteBook.addActionListener(this::btnDeleteBookActionPerformed);
        jPanel4.add(btnDeleteBook, new org.netbeans.lib.awtextra.AbsoluteConstraints(490, 150, -1, 60));
        jPanel4.add(lblPreview, new org.netbeans.lib.awtextra.AbsoluteConstraints(88, 40, 160, 180));

        jPanel1.add(jPanel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(330, 490, 700, 240));

        getContentPane().add(jPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 1140, 730));

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void btnAddBookActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnAddBookActionPerformed
String title = txtTitle.getText().trim();
    String author = txtAuthor.getText().trim();
    String category = comboCategory.getSelectedItem().toString();
    String status = comboStatus.getSelectedItem().toString(); // Use the combo box value
    String content = txtDescription.getText().trim(); 
    String path = txtFilePath.getText().trim(); // Get the path from your new browse field

    // 2. Validation
    if(title.isEmpty() || content.isEmpty() || path.isEmpty()){
        javax.swing.JOptionPane.showMessageDialog(this, "Please fill in the Title, Content, and select an Image!");
        return;
    }

    // 3. SQL Query - Added file_path to the columns
    String sql = "INSERT INTO books (book_title, author, category, status, description, file_path) VALUES (?, ?, ?, ?, ?, ?)";

    try (java.sql.Connection con = ticaro.ui.CONNECTION.getConnection();
         java.sql.PreparedStatement pst = con.prepareStatement(sql)) {
        
        pst.setString(1, title);
        pst.setString(2, author.isEmpty() ? "Unknown" : author);
        pst.setString(3, category);
        pst.setString(4, status); 
        pst.setString(5, content);
        pst.setString(6, path); // This saves the location of the image cover

        int result = pst.executeUpdate();
        
        if(result > 0) {
            javax.swing.JOptionPane.showMessageDialog(this, "Book Added Successfully!");
            loadBooks(); // Refresh your admin table
            
            // Clear all fields for the next entry
            txtTitle.setText("");
            txtAuthor.setText("");
            txtDescription.setText("");
            txtFilePath.setText("");
            lblPreview.setIcon(null); // Clear image preview if you have one
        }
        
    } catch (java.sql.SQLException e) {
        javax.swing.JOptionPane.showMessageDialog(this, "Database Error: " + e.getMessage());
        e.printStackTrace();
    }
    }//GEN-LAST:event_btnAddBookActionPerformed

    private void tblBooksMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tblBooksMouseClicked
  int row = tblBooks.getSelectedRow(); 
    txtBookId.setText(getValueSafe(row, 0));
    txtTitle.setText(getValueSafe(row, 1));
    txtAuthor.setText(getValueSafe(row, 2));
    String category = getValueSafe(row, 3);
    if (!category.isEmpty()) {
        comboCategory.setSelectedItem(category);
    }

    String status = getValueSafe(row, 4);
    if (!status.isEmpty()) {
        comboStatus.setSelectedItem(status);
    }

    }//GEN-LAST:event_tblBooksMouseClicked

    private void btnUpdateBookActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnUpdateBookActionPerformed
   String id = txtBookId.getText();
        String title = txtTitle.getText();
        String author = txtAuthor.getText();
        String category = comboCategory.getSelectedItem().toString();
        String status = comboStatus.getSelectedItem().toString();

        if (id.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Select a book from the table to update.");
            return;
        }

        try {
            Connection conn = DriverManager.getConnection(url, user, pass);
          
            String sql = "UPDATE books SET title=?, author=?, category=?, status=? WHERE id=?";
            PreparedStatement pst = conn.prepareStatement(sql);

            pst.setString(1, title);
            pst.setString(2, author);
            pst.setString(3, category);
            pst.setString(4, status);
            pst.setString(5, id);

            pst.executeUpdate();
            JOptionPane.showMessageDialog(this, "Record Updated Successfully!");

            loadBooks(); 
            conn.close();
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Update Error: " + e.getMessage());
        }
    }//GEN-LAST:event_btnUpdateBookActionPerformed

    private void btnDeleteBookActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnDeleteBookActionPerformed
                                            
    // 1. Get the selected row from the table (tblBooks)
    int selectedRow = tblBooks.getSelectedRow();

    // Check if the user actually clicked a row
    if (selectedRow == -1) {
        JOptionPane.showMessageDialog(this, "Please select a book from the table first.");
        return;
    }

    // 2. Get the ID from the first column (index 0) of the selected row
    String selectedBookId = tblBooks.getValueAt(selectedRow, 0).toString();

    // 3. The logic to "Hide" the book
    try (Connection conn = CONNECTION.getConnection()) {
        String sql = "UPDATE books SET is_visible = 0 WHERE id = ?";
        PreparedStatement pst = conn.prepareStatement(sql);
        pst.setString(1, selectedBookId);
        
        int rowsUpdated = pst.executeUpdate();
        
        if (rowsUpdated > 0) {
            JOptionPane.showMessageDialog(this, "Book hidden from the system!");
            // Refresh the table so the book disappears immediately
            loadBooks(); 
        }
    } catch (Exception e) {
        JOptionPane.showMessageDialog(this, "Error: " + e.getMessage());
    }
    }//GEN-LAST:event_btnDeleteBookActionPerformed

    private void btnclearbookActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnclearbookActionPerformed
   clearFields();
    }                                            

    private void clearFields() {
        txtBookId.setText("");
        txtTitle.setText("");
        txtAuthor.setText("");
        comboCategory.setSelectedIndex(0);
        comboStatus.setSelectedIndex(0);
  
    }//GEN-LAST:event_btnclearbookActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
     
    ADMIN backPage = new ADMIN(); 
    
  
    backPage.setVisible(true); 
    
  
    this.dispose();
    }//GEN-LAST:event_jButton1ActionPerformed

    private void REFRESH_BTNActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_REFRESH_BTNActionPerformed
    
    txtBookId.setText("");
    txtTitle.setText("");
    txtAuthor.setText("");
    comboCategory.setSelectedIndex(0);
    comboStatus.setSelectedIndex(0);
    
  
    loadBooks(); 
    System.out.println("Data refreshed successfully.");

    }//GEN-LAST:event_REFRESH_BTNActionPerformed

    private void btnBrowseActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnBrowseActionPerformed
        JFileChooser chooser = new JFileChooser();
    chooser.showOpenDialog(null);
    File f = chooser.getSelectedFile();
    
    if (f != null) {
        String filename = f.getAbsolutePath();
        txtFilePath.setText(filename); // This puts the path into your text field
        
        // Optional: Preview the image in a label if you have one
        ImageIcon icon = new ImageIcon(filename);
        Image img = icon.getImage().getScaledInstance(lblPreview.getWidth(), lblPreview.getHeight(), Image.SCALE_SMOOTH);
        lblPreview.setIcon(new ImageIcon(img));
    }
    }//GEN-LAST:event_btnBrowseActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ReflectiveOperationException | javax.swing.UnsupportedLookAndFeelException ex) {
            logger.log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(() -> new Book_Management().setVisible(true));
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton REFRESH_BTN;
    private javax.swing.JButton btnAddBook;
    private javax.swing.JButton btnBrowse;
    private javax.swing.JButton btnDeleteBook;
    private javax.swing.JButton btnUpdateBook;
    private javax.swing.JButton btnclearbook;
    private javax.swing.JComboBox<String> comboCategory;
    private javax.swing.JComboBox<String> comboStatus;
    private javax.swing.JButton jButton1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JLabel lblPreview;
    private javax.swing.JTable tblBooks;
    private javax.swing.JTextField txtAuthor;
    private javax.swing.JTextField txtBookId;
    private javax.swing.JTextArea txtDescription;
    private javax.swing.JTextField txtFilePath;
    private javax.swing.JTextField txtTitle;
    // End of variables declaration//GEN-END:variables
private String getValueSafe(int row, int col) {
        Object value = tblBooks.getValueAt(row, col);
        return (value == null) ? "" : value.toString();
    }
}
