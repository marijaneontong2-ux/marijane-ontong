package MAIN;
import java.sql.Connection;
import java.sql.DriverManager;
import ticaro.ui.CONNECTION;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
/**
 *
 * @author MARY GANE
 */
public class student_users extends javax.swing.JFrame {
    
    private static final java.util.logging.Logger logger = java.util.logging.Logger.getLogger(student_users.class.getName());

    /**
     * Creates new form student_users
     */
    public student_users() {
        initComponents();
        showData();
    }

  public void showData() {
    try {
        // 1. Establish connection and fetch all users
        java.sql.Connection con = CONNECTION.getConnection();
        String query = "SELECT * FROM `users`";
        java.sql.PreparedStatement ps = con.prepareStatement(query);
        java.sql.ResultSet rs = ps.executeQuery();

        // 2. Get the table model and clear existing rows
        javax.swing.table.DefaultTableModel model = (javax.swing.table.DefaultTableModel)jTable1.getModel();
        model.setRowCount(0);

      while(rs.next()) {
    Object[] row = new Object[5]; 
    
    String sid = rs.getString("student_id");
    String name = rs.getString("first_name") + " " + rs.getString("last_name");
    String email = rs.getString("email");
    String course = rs.getString("course"); // Pull the real course from DB
    String status = rs.getString("status");

    if ("Inactive".equalsIgnoreCase(status)) {
        row[0] = "<html><strike>" + sid + "</strike></html>";
        row[1] = "<html><strike>" + name + "</strike></html>";
        row[2] = "<html><strike>" + email + "</strike></html>";
        row[3] = "<html><strike>" + course + "</strike></html>";
        row[4] = "<html><strike>" + status + "</strike></html>";
    } else {
        row[0] = sid;
        row[1] = name;
        row[2] = email;
        row[3] = course; 
        row[4] = status;
    }
    
    model.addRow(row);
}

    } catch (java.sql.SQLException ex) {
        java.util.logging.Logger.getLogger(student_users.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
    }
}
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jSlider1 = new javax.swing.JSlider();
        jPanel1 = new javax.swing.JPanel();
        jPanel2 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jButton2 = new javax.swing.JButton();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        txtEmail = new javax.swing.JTextField();
        txtStudentId = new javax.swing.JTextField();
        txtStudentName = new javax.swing.JTextField();
        comboCourse = new javax.swing.JComboBox<>();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        jButton1 = new javax.swing.JButton();
        btnInsert = new javax.swing.JButton();
        btnUpdate = new javax.swing.JButton();
        btnDelete = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel1.setBackground(new java.awt.Color(255, 255, 255));
        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel2.setBackground(new java.awt.Color(0, 0, 0));

        jLabel1.setFont(new java.awt.Font("Segoe UI Emoji", 1, 24)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 255, 255));
        jLabel1.setText("STUDENT ");

        jButton2.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        jButton2.setText("BACK");
        jButton2.addActionListener(this::jButton2ActionPerformed);

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap(389, Short.MAX_VALUE)
                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 185, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(360, 360, 360)
                .addComponent(jButton2, javax.swing.GroupLayout.PREFERRED_SIZE, 90, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGap(14, 14, 14)
                        .addComponent(jButton2, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGap(38, 38, 38)
                        .addComponent(jLabel1)))
                .addContainerGap(46, Short.MAX_VALUE))
        );

        jPanel1.add(jPanel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 1030, -1));

        jLabel2.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jPanel1.add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 260, -1, -1));

        jLabel3.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel3.setText("STUDENT ID");
        jPanel1.add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 160, -1, -1));

        jLabel4.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel4.setText("COURSE");
        jPanel1.add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 320, -1, -1));

        jLabel5.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel5.setText("STUDENT NAME");
        jPanel1.add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 220, -1, -1));

        jLabel6.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel6.setText("EMAIL");
        jPanel1.add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 280, -1, -1));

        txtEmail.setFont(new java.awt.Font("Segoe UI Emoji", 1, 14)); // NOI18N
        txtEmail.addActionListener(this::txtEmailActionPerformed);
        jPanel1.add(txtEmail, new org.netbeans.lib.awtextra.AbsoluteConstraints(220, 270, 390, 40));

        txtStudentId.setFont(new java.awt.Font("Segoe UI Emoji", 1, 14)); // NOI18N
        txtStudentId.addActionListener(this::txtStudentIdActionPerformed);
        jPanel1.add(txtStudentId, new org.netbeans.lib.awtextra.AbsoluteConstraints(220, 150, 390, 40));

        txtStudentName.setFont(new java.awt.Font("Segoe UI Emoji", 1, 14)); // NOI18N
        txtStudentName.addActionListener(this::txtStudentNameActionPerformed);
        jPanel1.add(txtStudentName, new org.netbeans.lib.awtextra.AbsoluteConstraints(220, 210, 390, 40));

        comboCourse.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "BSIT ", "BSCS", "BSHM", "BSBA", "BSA", "TESDA", " ", " ", " " }));
        jPanel1.add(comboCourse, new org.netbeans.lib.awtextra.AbsoluteConstraints(220, 330, 390, 40));

        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null}
            },
            new String [] {
                "STUDENT ID", "STUDENT NAME", "EMAIL", "COURSE", "STATUS"
            }
        ));
        jTable1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jTable1MouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(jTable1);

        jPanel1.add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 490, 1030, -1));

        jButton1.setBackground(new java.awt.Color(204, 0, 0));
        jButton1.setFont(new java.awt.Font("Segoe UI Emoji", 1, 14)); // NOI18N
        jButton1.setText("INACTIVE");
        jButton1.addActionListener(this::jButton1ActionPerformed);
        jPanel1.add(jButton1, new org.netbeans.lib.awtextra.AbsoluteConstraints(720, 420, 120, 40));

        btnInsert.setBackground(new java.awt.Color(51, 255, 0));
        btnInsert.setFont(new java.awt.Font("Segoe UI Emoji", 1, 14)); // NOI18N
        btnInsert.setText("INSERT");
        btnInsert.addActionListener(this::btnInsertActionPerformed);
        jPanel1.add(btnInsert, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 420, 120, 40));

        btnUpdate.setBackground(new java.awt.Color(255, 255, 0));
        btnUpdate.setFont(new java.awt.Font("Segoe UI Emoji", 1, 14)); // NOI18N
        btnUpdate.setText("UPDATE");
        btnUpdate.addActionListener(this::btnUpdateActionPerformed);
        jPanel1.add(btnUpdate, new org.netbeans.lib.awtextra.AbsoluteConstraints(270, 420, 120, 40));

        btnDelete.setBackground(new java.awt.Color(255, 0, 0));
        btnDelete.setFont(new java.awt.Font("Segoe UI Emoji", 1, 14)); // NOI18N
        btnDelete.setText("DELETE");
        btnDelete.addActionListener(this::btnDeleteActionPerformed);
        jPanel1.add(btnDelete, new org.netbeans.lib.awtextra.AbsoluteConstraints(500, 420, 120, 40));

        getContentPane().add(jPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 1030, 870));

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void txtEmailActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtEmailActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtEmailActionPerformed

    private void txtStudentIdActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtStudentIdActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtStudentIdActionPerformed

    private void txtStudentNameActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtStudentNameActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtStudentNameActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
      String sid = txtStudentId.getText();

    if(sid.isEmpty()) {
        javax.swing.JOptionPane.showMessageDialog(this, "Please select a student from the table first!");
        return;
    }

    // 1. Update the database status to 'Inactive'
    String query = "UPDATE `users` SET `status`='Inactive' WHERE `student_id`=?";
    
    try (java.sql.Connection con = CONNECTION.getConnection();
         java.sql.PreparedStatement ps = con.prepareStatement(query)) {
        
        ps.setString(1, sid);
        
        if(ps.executeUpdate() > 0) {
            // 2. SUCCESS! Now refresh the table to show the strike-through
            showData(); 
            javax.swing.JOptionPane.showMessageDialog(this, "Student account is now INACTIVE.");
        }
    } catch (java.sql.SQLException ex) {
        java.util.logging.Logger.getLogger(this.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        javax.swing.JOptionPane.showMessageDialog(this, "Error updating status: " + ex.getMessage());
    }
    }//GEN-LAST:event_jButton1ActionPerformed

    private void btnInsertActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnInsertActionPerformed
    String sid = txtStudentId.getText().trim();
    String fullName = txtStudentName.getText().trim();
    String email = txtEmail.getText().trim();
    String course = comboCourse.getSelectedItem().toString();

    // 2. Splitting name to match database columns (first_name, last_name)
    if(fullName.isEmpty()) {
        javax.swing.JOptionPane.showMessageDialog(this, "Student Name is required");
        return;
    }
    
    String[] nameParts = fullName.split(" ", 2);
    String fname = nameParts[0];
    String lname = (nameParts.length > 1) ? nameParts[1] : "";

    // 3. Validation for required fields
    if(sid.isEmpty() || email.isEmpty()) {
        javax.swing.JOptionPane.showMessageDialog(this, "Please fill in all required fields (ID and Email)");
        return;
    }

    // 4. SQL Query - Ensure you have 6 columns and 6 question marks
    String query = "INSERT INTO `users`(`first_name`, `last_name`, `email`, `course`, `student_id`, `status`) VALUES (?,?,?,?,?,?)";
    
    try (java.sql.Connection con = CONNECTION.getConnection();
         java.sql.PreparedStatement ps = con.prepareStatement(query)) {
        
        // 5. Set values (Match the order of the query above)
        ps.setString(1, fname);    // first_name
        ps.setString(2, lname);    // last_name
        ps.setString(3, email);    // email
        ps.setString(4, course);   // course
        ps.setString(5, sid);      // student_id
        ps.setString(6, "Active"); // status (default to Active)

        // 6. Execute and Update UI
        if(ps.executeUpdate() > 0) {
            showData(); // Refresh the JTable immediately
            
            javax.swing.JOptionPane.showMessageDialog(this, "New Student Account Created!");
            
            // 7. Clear the form for the next entry
            txtStudentId.setText("");
            txtStudentName.setText("");
            txtEmail.setText("");
            comboCourse.setSelectedIndex(0); 
        }
        
    } catch (java.sql.SQLException ex) {
        // Detailed error logging
        java.util.logging.Logger.getLogger(this.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        javax.swing.JOptionPane.showMessageDialog(this, "Database Error: " + ex.getMessage());
    }

    }//GEN-LAST:event_btnInsertActionPerformed

    private void btnUpdateActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnUpdateActionPerformed
      String sid = txtStudentId.getText();
    String fullName = txtStudentName.getText();
    String email = txtEmail.getText();
    
    String[] nameParts = fullName.split(" ", 2);
    String fname = nameParts[0];
    String lname = (nameParts.length > 1) ? nameParts[1] : "";

   String query = "UPDATE `users` SET `first_name`=?, `last_name`=?, `email`=?, `course`=? WHERE `student_id`=?";
    
    try (java.sql.Connection con = CONNECTION.getConnection();
         java.sql.PreparedStatement ps = con.prepareStatement(query)) {
        
        ps.setString(1, fname);
        ps.setString(2, lname);
        ps.setString(3, email);
        ps.setString(4, sid);
        ps.setString(4, comboCourse.getSelectedItem().toString());
ps.setString(5, sid);
        if(ps.executeUpdate() > 0) {
            javax.swing.JOptionPane.showMessageDialog(this, "Student Updated Successfully!");
            showData(); // Refresh the table
        }
    } catch (java.sql.SQLException ex) {
        java.util.logging.Logger.getLogger(this.getName()).log(java.util.logging.Level.SEVERE, null, ex);
    }
    }//GEN-LAST:event_btnUpdateActionPerformed

    private void btnDeleteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnDeleteActionPerformed
      String sid = txtStudentId.getText();

    if(sid.isEmpty()) {
        javax.swing.JOptionPane.showMessageDialog(this, "Please enter or select a Student ID to delete.");
        return;
    }

    int confirm = javax.swing.JOptionPane.showConfirmDialog(this, "Are you sure you want to delete this student?", "Confirm Delete", javax.swing.JOptionPane.YES_NO_OPTION);
    
    if(confirm == javax.swing.JOptionPane.YES_OPTION) {
        String query = "DELETE FROM `users` WHERE `student_id`=?";
        
        try (java.sql.Connection con = CONNECTION.getConnection();
             java.sql.PreparedStatement ps = con.prepareStatement(query)) {
            
            ps.setString(1, sid);

            if(ps.executeUpdate() > 0) {
                javax.swing.JOptionPane.showMessageDialog(this, "Student Deleted.");
                showData();
                // Clear fields
                txtStudentId.setText("");
                txtStudentName.setText("");
                txtEmail.setText("");
            }
        } catch (java.sql.SQLException ex) {
            java.util.logging.Logger.getLogger(this.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
    }
    }//GEN-LAST:event_btnDeleteActionPerformed

    private void jTable1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jTable1MouseClicked
      // 1. Get the table model
    javax.swing.table.DefaultTableModel model = (javax.swing.table.DefaultTableModel)jTable1.getModel();
    
    // 2. Find out which row was clicked
    int selectedRowIndex = jTable1.getSelectedRow();
    
    // 3. Set the text fields with data from that row
    // .toString() helps remove any HTML tags like <strike> from the display
    txtStudentId.setText(model.getValueAt(selectedRowIndex, 0).toString().replaceAll("<[^>]*>", ""));
    txtStudentName.setText(model.getValueAt(selectedRowIndex, 1).toString().replaceAll("<[^>]*>", ""));
    txtEmail.setText(model.getValueAt(selectedRowIndex, 2).toString().replaceAll("<[^>]*>", ""));
    
    // Set the combobox (optional)
    Object courseValue = model.getValueAt(selectedRowIndex, 3);
    if(courseValue != null) {
        comboCourse.setSelectedItem(courseValue.toString().replaceAll("<[^>]*>", ""));
    }
    }//GEN-LAST:event_jTable1MouseClicked

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed

        ADMIN backPage = new ADMIN();

        backPage.setVisible(true);

        this.dispose();
    }//GEN-LAST:event_jButton2ActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ReflectiveOperationException | javax.swing.UnsupportedLookAndFeelException ex) {
            logger.log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(() -> new student_users().setVisible(true));
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnDelete;
    private javax.swing.JButton btnInsert;
    private javax.swing.JButton btnUpdate;
    private javax.swing.JComboBox<String> comboCourse;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JSlider jSlider1;
    private javax.swing.JTable jTable1;
    private javax.swing.JTextField txtEmail;
    private javax.swing.JTextField txtStudentId;
    private javax.swing.JTextField txtStudentName;
    // End of variables declaration//GEN-END:variables
}
