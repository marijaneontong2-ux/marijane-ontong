package MAIN;
import java.sql.*;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

public class DASHBOARD extends javax.swing.JFrame {

    public DASHBOARD() {
        initComponents();      
        updateDashboardData(); 
    }
    
    private Connection getConnection() throws SQLException {
        return DriverManager.getConnection("jdbc:mysql://localhost:3306/library_system", "root", "");
    }

    public void updateDashboardData() {
        try (Connection conn = getConnection()) {
            // Count Borrowed
            try (PreparedStatement pst = conn.prepareStatement("SELECT COUNT(*) FROM borrowed_books WHERE status = 'Borrowed'")) {
                ResultSet rs = pst.executeQuery();
                if (rs.next()) lblBorrowedCount.setText(rs.getString(1));
            }
            // Count Available
            try (PreparedStatement pst = conn.prepareStatement("SELECT COUNT(*) FROM books WHERE status = 'Available'")) {
                ResultSet rs = pst.executeQuery();
                if (rs.next()) lblAvailableCount.setText(rs.getString(1));
            }
            // Count Users
            try (PreparedStatement pst = conn.prepareStatement("SELECT COUNT(*) FROM users")) {
                ResultSet rs = pst.executeQuery();
                if (rs.next()) USERS.setText(rs.getString(1));
            }
            loadTableData("");
        } catch (Exception e) {
            System.out.println("Dashboard Error: " + e.getMessage());
        }
    }

    private void loadTableData(String query) {
        // Updated SQL to ensure column names match what exists in your DB
        String sql = "SELECT id, student_name, student_id, book_title, status FROM borrowed_books";
        if (!query.isEmpty()) {
            sql += " WHERE book_title LIKE ? OR student_name LIKE ?";
        }

        try (Connection conn = getConnection();
             PreparedStatement pst = conn.prepareStatement(sql)) {
            
            if (!query.isEmpty()) {
                pst.setString(1, "%" + query + "%");
                pst.setString(2, "%" + query + "%");
            }

            ResultSet rs = pst.executeQuery();
            DefaultTableModel model = (DefaultTableModel) jTable1.getModel();
            model.setRowCount(0); 

            while (rs.next()) {
                model.addRow(new Object[]{
                    rs.getInt("id"),           
                    rs.getString("student_name"),
                    rs.getString("student_id"),
                    rs.getString("book_title"),
                    rs.getString("status")
                });
            }
        } catch (Exception e) {
            System.out.println("Table Error: " + e.getMessage());
        }
    }  
   

                                         

   
    
   
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jPanel2 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        btnBack = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        jLabel2 = new javax.swing.JLabel();
        lblAvailableCount = new javax.swing.JTextField();
        jLabel3 = new javax.swing.JLabel();
        lblBorrowedCount = new javax.swing.JTextField();
        return_btn = new javax.swing.JButton();
        USERS = new javax.swing.JTextField();
        jLabel5 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel1.setBackground(new java.awt.Color(51, 51, 51));
        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel2.setBackground(new java.awt.Color(0, 0, 0));
        jPanel2.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel1.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 255, 255));
        jLabel1.setText("M.A.S DASHBOARD");
        jPanel2.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(460, 20, -1, -1));

        btnBack.setText("BACK");
        btnBack.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnBackActionPerformed(evt);
            }
        });
        jPanel2.add(btnBack, new org.netbeans.lib.awtextra.AbsoluteConstraints(1010, 13, -1, 30));

        jPanel1.add(jPanel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 1090, 70));

        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null}
            },
            new String [] {
                "ID", "NAME", "BOOK ID", "BORROWED BOOKS", "STATUS"
            }
        ));
        jTable1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jTable1MouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(jTable1);

        jPanel1.add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(340, 70, 750, 560));

        jLabel2.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(255, 255, 255));
        jLabel2.setText("USERS");
        jPanel1.add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 270, -1, 20));
        jPanel1.add(lblAvailableCount, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 390, 140, 40));

        jLabel3.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(255, 255, 255));
        jLabel3.setText("BOOKS BORROWED");
        jPanel1.add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 100, -1, 20));

        lblBorrowedCount.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                lblBorrowedCountActionPerformed(evt);
            }
        });
        jPanel1.add(lblBorrowedCount, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 130, 140, 40));

        return_btn.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        return_btn.setText("RETURN BOOK");
        return_btn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                return_btnActionPerformed(evt);
            }
        });
        jPanel1.add(return_btn, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 200, 150, 40));
        jPanel1.add(USERS, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 300, 140, 40));

        jLabel5.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        jLabel5.setForeground(new java.awt.Color(255, 255, 255));
        jLabel5.setText("AVAILABLE BOOKS");
        jPanel1.add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 360, -1, 20));

        getContentPane().add(jPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 1090, 630));

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void return_btnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_return_btnActionPerformed
int selectedRow = jTable1.getSelectedRow();
    if (selectedRow == -1) {
        javax.swing.JOptionPane.showMessageDialog(this, "Please select a book to return!");
        return;
    }

    // 1. GET DATA FROM TABLE
    String transactionId = jTable1.getValueAt(selectedRow, 0).toString(); 
    String studentName   = jTable1.getValueAt(selectedRow, 1).toString(); 
    String studentId     = jTable1.getValueAt(selectedRow, 2).toString(); // Make sure this index matches your table!
    String bookTitle     = jTable1.getValueAt(selectedRow, 3).toString(); 

    try (Connection conn = getConnection()) {
        conn.setAutoCommit(false); 

        // A. Update Borrowed Books Table Status
        String sqlUpdateBorrow = "UPDATE borrowed_books SET status = 'Returned' WHERE id = ?";
        try (PreparedStatement pst1 = conn.prepareStatement(sqlUpdateBorrow)) {
            pst1.setString(1, transactionId);
            pst1.executeUpdate();
        }

        // B. PASTE YOUR CODE HERE (Insert into Return History)
        String sqlInsertHistory = "INSERT INTO returned_books (student_id, student_name, book_title, return_date) VALUES (?, ?, ?, CURRENT_TIMESTAMP)";
        try (PreparedStatement pst2 = conn.prepareStatement(sqlInsertHistory)) {
            pst2.setString(1, studentId);   
            pst2.setString(2, studentName);
            pst2.setString(3, bookTitle);
            pst2.executeUpdate();
        }

        // C. Update Book Status to Available
        String sqlUpdateBook = "UPDATE books SET status = 'Available' WHERE book_title = ?"; 
        try (PreparedStatement pst3 = conn.prepareStatement(sqlUpdateBook)) {
            pst3.setString(1, bookTitle);
            pst3.executeUpdate();
        }

        conn.commit(); // Saves all three changes at once
        javax.swing.JOptionPane.showMessageDialog(this, "Book Returned Successfully!");
        
        updateDashboardData(); // Refreshes your dashboard counts and table

    } catch (Exception e) {
        System.out.println("Return Error: " + e.getMessage());
        e.printStackTrace();
        javax.swing.JOptionPane.showMessageDialog(this, "Database Error: " + e.getMessage());
    }
    
    }//GEN-LAST:event_return_btnActionPerformed

    private void btnBackActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnBackActionPerformed
     
    ADMIN backPage = new ADMIN(); 
    backPage.setVisible(true); 
    this.dispose();
    }//GEN-LAST:event_btnBackActionPerformed

    private void jTable1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jTable1MouseClicked
        // TODO add your handling code here:
    }//GEN-LAST:event_jTable1MouseClicked

    private void lblBorrowedCountActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_lblBorrowedCountActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_lblBorrowedCountActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(DASHBOARD.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(DASHBOARD.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(DASHBOARD.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(DASHBOARD.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new DASHBOARD().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTextField USERS;
    private javax.swing.JButton btnBack;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable jTable1;
    private javax.swing.JTextField lblAvailableCount;
    private javax.swing.JTextField lblBorrowedCount;
    private javax.swing.JButton return_btn;
    // End of variables declaration//GEN-END:variables

   

}
