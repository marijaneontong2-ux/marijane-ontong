package ROMANCE;
import ticaro.ui.DASHBOARD3;
import ticaro.ui.REVIEW_BOOK;
import ticaro.ui.borrow_form;

/**
 *
 * @author Alethea Jae
 */
public class BOOK3 extends javax.swing.JFrame {
    
    private static final java.util.logging.Logger logger = java.util.logging.Logger.getLogger(BOOK3.class.getName());

    /**
     * Creates new form BOOK3
     */
    public BOOK3() {
        initComponents();
   checkBookStatus();
    }
    
private void checkBookStatus() {
    try {
        // 1. Connect to your database (using your 'coffee_pos' or 'library_db')
        java.sql.Connection conn = java.sql.DriverManager.getConnection("jdbc:mysql://localhost:3306/library_system", "root", "");
        
        // 2. Query to check the status of this specific book
        String sql = "SELECT status FROM books WHERE book_title = 'THE SUMMER YOU WHERE THERE BY: NAGISA FURUYA'";
        java.sql.PreparedStatement pst = conn.prepareStatement(sql);
        java.sql.ResultSet rs = pst.executeQuery();

        if (rs.next()) {
            String status = rs.getString("status");
            
            // 3. If the book is borrowed, change the button automatically
            if (status.equalsIgnoreCase("BORROWED")) {
                lblBookTitle.setText("BORROWED");
                lblBookTitle.setEnabled(false);
                lblBookTitle.setBackground(java.awt.Color.GRAY);
            } else {
                // If it was returned, it stays/becomes AVAILABLE
                lblBookTitle.setText("BORROW");
                lblBookTitle.setEnabled(true);
                lblBookTitle.setBackground(new java.awt.Color(255, 255, 255));
            }
        }
        conn.close();
    } catch (Exception e) {
        System.out.println("Error: " + e.getMessage());
    }
}
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTextArea1 = new javax.swing.JTextArea();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        lblBookTitle = new javax.swing.JButton();
        jButton2 = new javax.swing.JButton();
        btnmarkasread = new javax.swing.JButton();
        btnfavorites = new javax.swing.JButton();
        jButton3 = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel1.setBackground(new java.awt.Color(255, 255, 255));
        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jTextArea1.setColumns(20);
        jTextArea1.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jTextArea1.setRows(5);
        jTextArea1.setText("\n\t\t\t        The Summer You Were There\n\t\t\t                     Nagisa Furuya\n\n\tYoshiki lived a quiet life in a rural village until his best friend Hikaru returned after going missing in the mountains, looking \ncompletely normal yet feeling strangely different. From the moment they met again, Yoshiki sensed something was wrong, and one day, \nunable to ignore it any longer, he directly asked if he was really Hikaru. The truth came out without resistance the real Hikaru had died, and\nthe being in front of him was something else that had taken his place, copying everything about him. Despite the fear and shock, Yoshiki \nchose to stay, unable to let go of the person who still looked and acted like his best friend. As days passed, they continued their usual \nroutines walking together, talking, and spending time like nothing had changed but beneath it all was a growing tension, as the “new \nHikaru” struggled to understand human emotions while becoming deeply attached to Yoshiki.\n\n\tMeanwhile, strange and unsettling events began happening around the village, with whispers of disappearances and \nsomething unnatural lurking nearby making it clear that the presence inside Hikaru was connected to something far more dangerous. \nYoshiki found himself torn between fear and comfort, questioning whether he was holding onto his friend or slowly accepting a monster,\nyet he continued to stay by his side, knowing that even if the real Hikaru was gone, this was the only version of him he had left. struggled \nto understand human emotions while becoming deeply attached to Yoshiki.\n\n\tYoshiki lived a quiet life in a rural village until his best friend Hikaru returned after going missing in the mountains, looking \ncompletely normal yet feeling strangely different. From the moment they met again, Yoshiki sensed something was wrong, and one day, \nunable to ignore it any longer, he directly asked if he was really Hikaru. The truth came out without resistance the real Hikaru had died, and\nthe being in front of him was something else that had taken his place, copying everything about him. Despite the fear and shock, Yoshiki \nchose to stay, unable to let go of the person who still looked and acted like his best friend. As days passed, they continued their usual \nroutines walking together, talking, and spending time like nothing had changed but beneath it all was a growing tension, as the “new \nHikaru” struggled to understand human emotions while becoming deeply attached to Yoshiki.\n\n\tMeanwhile, strange and unsettling events began happening around the village, with whispers of disappearances and \nsomething unnatural lurking nearby making it clear that the presence inside Hikaru was connected to something far more dangerous. \nYoshiki found himself torn between fear and comfort, questioning whether he was holding onto his friend or slowly accepting a monster,\nyet he continued to stay by his side, knowing that even if the real Hikaru was gone, this was the only version of him he had left. struggled \nto understand human emotions while becoming deeply attached to Yoshiki.\n\n\tYoshiki lived a quiet life in a rural village until his best friend Hikaru returned after going missing in the mountains, looking \ncompletely normal yet feeling strangely different. From the moment they met again, Yoshiki sensed something was wrong, and one day, \nunable to ignore it any longer, he directly asked if he was really Hikaru. The truth came out without resistance the real Hikaru had died, and\nthe being in front of him was something else that had taken his place, copying everything about him. Despite the fear and shock, Yoshiki \nchose to stay, unable to let go of the person who still looked and acted like his best friend. As days passed, they continued their usual \nroutines walking together, talking, and spending time like nothing had changed but beneath it all was a growing tension, as the “new \nHikaru” struggled to understand human emotions while becoming deeply attached to Yoshiki.\n\n\tMeanwhile, strange and unsettling events began happening around the village, with whispers of disappearances and \nsomething unnatural lurking nearby making it clear that the presence inside Hikaru was connected to something far more dangerous. \nYoshiki found himself torn between fear and comfort, questioning whether he was holding onto his friend or slowly accepting a monster,\nyet he continued to stay by his side, knowing that even if the real Hikaru was gone, this was the only version of him he had left. struggled \nto understand human emotions while becoming deeply attached to Yoshiki.");
        jScrollPane1.setViewportView(jTextArea1);

        jPanel1.add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(18, 16, 880, 636));

        jLabel4.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/1r8 (1).png"))); // NOI18N
        jPanel1.add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(520, 260, -1, -1));

        jLabel5.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/1r6 (1).png"))); // NOI18N
        jPanel1.add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(953, 85, 123, -1));

        lblBookTitle.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        lblBookTitle.setText("BORROW");
        lblBookTitle.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                lblBookTitleActionPerformed(evt);
            }
        });
        jPanel1.add(lblBookTitle, new org.netbeans.lib.awtextra.AbsoluteConstraints(941, 251, 135, -1));

        jButton2.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        jButton2.setText("REVIEWS");
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });
        jPanel1.add(jButton2, new org.netbeans.lib.awtextra.AbsoluteConstraints(941, 285, 135, -1));

        btnmarkasread.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        btnmarkasread.setText("MARK AS READ");
        btnmarkasread.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnmarkasreadActionPerformed(evt);
            }
        });
        jPanel1.add(btnmarkasread, new org.netbeans.lib.awtextra.AbsoluteConstraints(941, 319, 135, -1));

        btnfavorites.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        btnfavorites.setText("FAVORITES");
        btnfavorites.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnfavoritesActionPerformed(evt);
            }
        });
        jPanel1.add(btnfavorites, new org.netbeans.lib.awtextra.AbsoluteConstraints(941, 353, 135, -1));

        jButton3.setText("BACK");
        jButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton3ActionPerformed(evt);
            }
        });
        jPanel1.add(jButton3, new org.netbeans.lib.awtextra.AbsoluteConstraints(960, 30, -1, -1));

        getContentPane().add(jPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(49, 14, -1, -1));

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void lblBookTitleActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_lblBookTitleActionPerformed
      lblBookTitle.setText("BORROWED");
    lblBookTitle.setEnabled(false);
    
   
    try {
       
        java.sql.Connection conn = java.sql.DriverManager.getConnection("jdbc:mysql://localhost:3306/library_system", "root", "");
        
      
        String sql = "UPDATE books SET status = 'BORROWED' WHERE book_title = 'THE SUMMER YOU WHERE THERE BY: NAGISA FURUYA'";
        
        java.sql.PreparedStatement pst = conn.prepareStatement(sql);
        pst.executeUpdate(); 
        
        conn.close();
    } catch (Exception e) {
      
        System.out.println("Database Update Error: " + e.getMessage());
    }
        borrow_form bf = new borrow_form(); 
    
   
    bf.txtBookTitle.setText("THE SUMMER YOU WHERE THERE BY: NAGISA FURUYA"); 
    bf.setVisible(true);
    }//GEN-LAST:event_lblBookTitleActionPerformed

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
       String bookTitle = "THE SUMMER YOU WHERE THERE BY:NAGISA FURUYA"; 

  
    REVIEW_BOOK rf = new REVIEW_BOOK();
    rf.lblReviewBookTitle.setText("SHARE YOUR THOUGHTS");
    rf.txtBookTitle.setText(bookTitle);
    
    rf.setVisible(true);
    }//GEN-LAST:event_jButton2ActionPerformed

    private void btnmarkasreadActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnmarkasreadActionPerformed
      javax.swing.JOptionPane.showMessageDialog(this, 
        "You have successfully marked 'THE SUMMER YOU WHERE THERE BY:NAGISA FURUYA' as Read!", 
        "Success", 
        javax.swing.JOptionPane.INFORMATION_MESSAGE);

    
    btnmarkasread.setText("COMPLETED");
    btnmarkasread.setEnabled(false);
    
    
    btnmarkasread.setBackground(new java.awt.Color(153, 255, 153)); 
    }//GEN-LAST:event_btnmarkasreadActionPerformed

    private void btnfavoritesActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnfavoritesActionPerformed
       javax.swing.JOptionPane.showMessageDialog(this, 
        "'THE SUMMER YOU WHERE THERE BY:NAGISA FURUYA' has been added to your Favorites!", 
        "Added to Favorites", 
        javax.swing.JOptionPane.INFORMATION_MESSAGE);

    
    btnfavorites.setText("❤ FAVORITED");
    
   
    btnfavorites.setBackground(new java.awt.Color(255, 204, 204));
    btnfavorites.setEnabled(false);
    }//GEN-LAST:event_btnfavoritesActionPerformed

    private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton3ActionPerformed
         DASHBOARD3 dashboardPage = new DASHBOARD3("1");
    dashboardPage.setVisible(true);
    
   
    this.dispose();
    }//GEN-LAST:event_jButton3ActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ReflectiveOperationException | javax.swing.UnsupportedLookAndFeelException ex) {
            logger.log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(() -> new BOOK3().setVisible(true));
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnfavorites;
    private javax.swing.JButton btnmarkasread;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTextArea jTextArea1;
    private javax.swing.JButton lblBookTitle;
    // End of variables declaration//GEN-END:variables
}
