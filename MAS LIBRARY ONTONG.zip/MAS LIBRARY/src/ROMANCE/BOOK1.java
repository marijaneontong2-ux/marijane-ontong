package ROMANCE;
import ticaro.ui.DASHBOARD3;
import ticaro.ui.REVIEW_BOOK;
import ticaro.ui.borrow_form;
/**
 *
 * @author Alethea Jae
 */
public class BOOK1 extends javax.swing.JFrame {
    
    private static final java.util.logging.Logger logger = java.util.logging.Logger.getLogger(BOOK1.class.getName());

    /**
     * Creates new form BOOK1
     */
    public BOOK1() {
        initComponents();
    checkBookStatus();
    }
    
private void checkBookStatus() {
    try {
        // 1. Connect to your database (using your 'coffee_pos' or 'library_db')
        java.sql.Connection conn = java.sql.DriverManager.getConnection("jdbc:mysql://localhost:3306/library_system", "root", "");
        
        // 2. Query to check the status of this specific book
        String sql = "SELECT status FROM books WHERE book_title = 'THE PATH NOAH MARA'";
        java.sql.PreparedStatement pst = conn.prepareStatement(sql);
        java.sql.ResultSet rs = pst.executeQuery();

        if (rs.next()) {
            String status = rs.getString("status");
            
            // 3. If the book is borrowed, change the button automatically
            if (status.equalsIgnoreCase("BORROWED")) {
                lblBookTitle.setText("BORROWED");
                lblBookTitle.setEnabled(false);
                lblBookTitle.setBackground(java.awt.Color.GRAY);
            } else {
                // If it was returned, it stays/becomes AVAILABLE
                lblBookTitle.setText("BORROW");
                lblBookTitle.setEnabled(true);
                lblBookTitle.setBackground(new java.awt.Color(255, 255, 255));
            }
        }
        conn.close();
    } catch (Exception e) {
        System.out.println("Error: " + e.getMessage());
    }
}
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTextArea1 = new javax.swing.JTextArea();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        lblBookTitle = new javax.swing.JButton();
        jButton2 = new javax.swing.JButton();
        btnmarkasread = new javax.swing.JButton();
        btnfavorites = new javax.swing.JButton();
        jButton3 = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel1.setBackground(new java.awt.Color(255, 255, 255));
        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jTextArea1.setColumns(20);
        jTextArea1.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jTextArea1.setRows(5);
        jTextArea1.setText("\n\t\t\t\tThe Path\n\t\t\t                       Noah Mora\n\n\tIn a quiet, forgotten part of the world, where the trees grew tall and the air felt still, a young traveler wandered alone. He \nhad been walking for days without a clear destination, guided only by the hope that somewhere ahead, he would find meaning, purpose, \nor at least a direction worth following. One afternoon, as the sun began to lower and cast long shadows across the forest floor, he arrived \nat a crossroads. It was unlike any place he had seen before. The trees around it seemed to stand farther apart, as if giving space for the \nmoment. The wind slowed down, and even the sounds of nature softened, creating an almost unnatural silence. It felt as though the world \nitself was waiting for him to decide. In front of him were two paths.\n\n\tThe first path stretched out wide and clear. Its surface was smooth, almost inviting, with no obstacles in sight. It was easy \nto see where it led straight ahead, predictable, and calm. There were footprints along it, signs that many others had walked this way before. \nIt looked safe. Familiar. Certain. The second path was entirely different. It was narrow and uneven, partly hidden by tall grass and creeping \nvines. The ground was rough, scattered with stones and roots that twisted unpredictably. It curved and disappeared into the dense forest,\noffering no clear view of what lay ahead. It felt uncertain, almost intimidating like a challenge waiting to be faced. The traveler stood still.\n\n\tAt first, he thought the decision would be simple. But as he looked more closely, the weight of the choice began to settle \nin. He imagined himself taking the first path. It would be easier. There would be fewer struggles, fewer risks. He could move forward without \nfear, following the footsteps of others who had already proven it was safe. Perhaps it would lead him to a stable and comfortable life. He \nimagined himself taking the first path. It would be easier. There would be fewer struggles, fewer risks. He could move forward without fear,\nfollowing the footsteps of others who had already proven it was safe. Perhaps it would lead him to a stable and comfortable life. \n\t\n\tIn a quiet, forgotten part of the world, where the trees grew tall and the air felt still, a young traveler wandered alone. He \nhad been walking for days without a clear destination, guided only by the hope that somewhere ahead, he would find meaning, purpose, \nor at least a direction worth following. One afternoon, as the sun began to lower and cast long shadows across the forest floor, he arrived \nat a crossroads. It was unlike any place he had seen before. The trees around it seemed to stand farther apart, as if giving space for the \nmoment. The wind slowed down, and even the sounds of nature softened, creating an almost unnatural silence. It felt as though the world \nitself was waiting for him to decide. In front of him were two paths.\n\n\tThe first path stretched out wide and clear. Its surface was smooth, almost inviting, with no obstacles in sight. It was easy \nto see where it led straight ahead, predictable, and calm. There were footprints along it, signs that many others had walked this way before. \nIt looked safe. Familiar. Certain. The second path was entirely different. It was narrow and uneven, partly hidden by tall grass and creeping \nvines. The ground was rough, scattered with stones and roots that twisted unpredictably. It curved and disappeared into the dense forest,\noffering no clear view of what lay ahead. It felt uncertain, almost intimidating like a challenge waiting to be faced. The traveler stood still.\n\n\tAt first, he thought the decision would be simple. But as he looked more closely, the weight of the choice began to settle \nin. He imagined himself taking the first path. It would be easier. There would be fewer struggles, fewer risks. He could move forward without \nfear, following the footsteps of others who had already proven it was safe. Perhaps it would lead him to a stable and comfortable life. He \nimagined himself taking the first path. It would be easier. There would be fewer struggles, fewer risks. He could move forward without fear,\nfollowing the footsteps of others who had already proven it was safe. Perhaps it would lead him to a stable and comfortable life. \n\n\tIn a quiet, forgotten part of the world, where the trees grew tall and the air felt still, a young traveler wandered alone. He \nhad been walking for days without a clear destination, guided only by the hope that somewhere ahead, he would find meaning, purpose, \nor at least a direction worth following. One afternoon, as the sun began to lower and cast long shadows across the forest floor, he arrived \nat a crossroads. It was unlike any place he had seen before. The trees around it seemed to stand farther apart, as if giving space for the \nmoment. The wind slowed down, and even the sounds of nature softened, creating an almost unnatural silence. It felt as though the world \nitself was waiting for him to decide. In front of him were two paths.\n\n\tThe first path stretched out wide and clear. Its surface was smooth, almost inviting, with no obstacles in sight. It was easy \nto see where it led straight ahead, predictable, and calm. There were footprints along it, signs that many others had walked this way before. \nIt looked safe. Familiar. Certain. The second path was entirely different. It was narrow and uneven, partly hidden by tall grass and creeping \nvines. The ground was rough, scattered with stones and roots that twisted unpredictably. It curved and disappeared into the dense forest,\noffering no clear view of what lay ahead. It felt uncertain, almost intimidating like a challenge waiting to be faced. The traveler stood still.\n\n\tAt first, he thought the decision would be simple. But as he looked more closely, the weight of the choice began to settle \nin. He imagined himself taking the first path. It would be easier. There would be fewer struggles, fewer risks. He could move forward without \nfear, following the footsteps of others who had already proven it was safe. Perhaps it would lead him to a stable and comfortable life. He \nimagined himself taking the first path. It would be easier. There would be fewer struggles, fewer risks. He could move forward without fear,\nfollowing the footsteps of others who had already proven it was safe. Perhaps it would lead him to a stable and comfortable life. ");
        jScrollPane1.setViewportView(jTextArea1);

        jPanel1.add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(18, 16, 880, 636));

        jLabel4.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/1r8 (1).png"))); // NOI18N
        jPanel1.add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(520, 260, -1, -1));

        jLabel5.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/1r8 (1).png"))); // NOI18N
        jPanel1.add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(953, 85, 123, -1));

        lblBookTitle.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        lblBookTitle.setText("BORROW");
        lblBookTitle.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                lblBookTitleActionPerformed(evt);
            }
        });
        jPanel1.add(lblBookTitle, new org.netbeans.lib.awtextra.AbsoluteConstraints(941, 273, 135, -1));

        jButton2.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        jButton2.setText("REVIEWS");
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });
        jPanel1.add(jButton2, new org.netbeans.lib.awtextra.AbsoluteConstraints(941, 307, 135, -1));

        btnmarkasread.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        btnmarkasread.setText("MARK AS READ");
        btnmarkasread.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnmarkasreadActionPerformed(evt);
            }
        });
        jPanel1.add(btnmarkasread, new org.netbeans.lib.awtextra.AbsoluteConstraints(941, 341, 135, -1));

        btnfavorites.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        btnfavorites.setText("FAVORITES");
        btnfavorites.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnfavoritesActionPerformed(evt);
            }
        });
        jPanel1.add(btnfavorites, new org.netbeans.lib.awtextra.AbsoluteConstraints(941, 375, 135, -1));

        jButton3.setText("BACK");
        jButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton3ActionPerformed(evt);
            }
        });
        jPanel1.add(jButton3, new org.netbeans.lib.awtextra.AbsoluteConstraints(970, 30, -1, -1));

        getContentPane().add(jPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 10, 1160, 680));

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void lblBookTitleActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_lblBookTitleActionPerformed
        lblBookTitle.setText("BORROWED");
    lblBookTitle.setEnabled(false);
    
   
    try {
       
        java.sql.Connection conn = java.sql.DriverManager.getConnection("jdbc:mysql://localhost:3306/library_system", "root", "");
        
      
        String sql = "UPDATE books SET status = 'BORROWED' WHERE book_title = 'THE PATH NOAH MARA'";
        
        java.sql.PreparedStatement pst = conn.prepareStatement(sql);
        pst.executeUpdate(); 
        
        conn.close();
    } catch (Exception e) {
      
        System.out.println("Database Update Error: " + e.getMessage());
    }
        borrow_form bf = new borrow_form(); 
    
   
    bf.txtBookTitle.setText("THE PATH NOAH MARA"); 
    bf.setVisible(true);
    }//GEN-LAST:event_lblBookTitleActionPerformed

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
      String bookTitle = "THE PATH NOAH MARA"; 

  
    REVIEW_BOOK rf = new REVIEW_BOOK();
    rf.lblReviewBookTitle.setText("SHARE YOUR THOUGHTS");
    rf.txtBookTitle.setText(bookTitle);
    
    rf.setVisible(true);
    }//GEN-LAST:event_jButton2ActionPerformed

    private void btnmarkasreadActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnmarkasreadActionPerformed
         javax.swing.JOptionPane.showMessageDialog(this, 
        "You have successfully marked 'THE PATH NOAH MARA' as Read!", 
        "Success", 
        javax.swing.JOptionPane.INFORMATION_MESSAGE);

    
    btnmarkasread.setText("COMPLETED");
    btnmarkasread.setEnabled(false);
    
    
    btnmarkasread.setBackground(new java.awt.Color(153, 255, 153)); 
    }//GEN-LAST:event_btnmarkasreadActionPerformed

    private void btnfavoritesActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnfavoritesActionPerformed
      javax.swing.JOptionPane.showMessageDialog(this, 
        "'THE PATH NOAH MARA' has been added to your Favorites!", 
        "Added to Favorites", 
        javax.swing.JOptionPane.INFORMATION_MESSAGE);

    
    btnfavorites.setText("❤ FAVORITED");
    
   
    btnfavorites.setBackground(new java.awt.Color(255, 204, 204));
    btnfavorites.setEnabled(false);
    }//GEN-LAST:event_btnfavoritesActionPerformed

    private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton3ActionPerformed
      DASHBOARD3 dashboardPage = new DASHBOARD3("1");
    dashboardPage.setVisible(true);
    
   
    this.dispose();
    }//GEN-LAST:event_jButton3ActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ReflectiveOperationException | javax.swing.UnsupportedLookAndFeelException ex) {
            logger.log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(() -> new BOOK1().setVisible(true));
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnfavorites;
    private javax.swing.JButton btnmarkasread;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTextArea jTextArea1;
    private javax.swing.JButton lblBookTitle;
    // End of variables declaration//GEN-END:variables
}
