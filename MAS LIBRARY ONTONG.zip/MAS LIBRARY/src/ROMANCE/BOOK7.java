package ROMANCE;
import ticaro.ui.DASHBOARD3;
import ticaro.ui.REVIEW_BOOK;
import ticaro.ui.borrow_form;


/**
 *
 * @author Alethea Jae
 */
public class BOOK7 extends javax.swing.JFrame {
    
    private static final java.util.logging.Logger logger = java.util.logging.Logger.getLogger(BOOK7.class.getName());

    /**
     * Creates new form BOOK7
     */
    public BOOK7() {
        initComponents();
     checkBookStatus();
    }
    
private void checkBookStatus() {
    try {
        // 1. Connect to your database (using your 'coffee_pos' or 'library_db')
        java.sql.Connection conn = java.sql.DriverManager.getConnection("jdbc:mysql://localhost:3306/library_system", "root", "");
        
        // 2. Query to check the status of this specific book
        String sql = "SELECT status FROM books WHERE book_title = 'See You Again Love'";
        java.sql.PreparedStatement pst = conn.prepareStatement(sql);
        java.sql.ResultSet rs = pst.executeQuery();

        if (rs.next()) {
            String status = rs.getString("status");
            
            // 3. If the book is borrowed, change the button automatically
            if (status.equalsIgnoreCase("BORROWED")) {
                lblBookTitle.setText("BORROWED");
                lblBookTitle.setEnabled(false);
                lblBookTitle.setBackground(java.awt.Color.GRAY);
            } else {
                // If it was returned, it stays/becomes AVAILABLE
                lblBookTitle.setText("BORROW");
                lblBookTitle.setEnabled(true);
                lblBookTitle.setBackground(new java.awt.Color(255, 255, 255));
            }
        }
        conn.close();
    } catch (Exception e) {
        System.out.println("Error: " + e.getMessage());
    }
}
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTextArea1 = new javax.swing.JTextArea();
        jLabel5 = new javax.swing.JLabel();
        lblBookTitle = new javax.swing.JButton();
        jButton2 = new javax.swing.JButton();
        btnmarkasread = new javax.swing.JButton();
        btnfavorites = new javax.swing.JButton();
        jButton3 = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel1.setBackground(new java.awt.Color(255, 255, 255));
        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jTextArea1.setColumns(20);
        jTextArea1.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jTextArea1.setRows(5);
        jTextArea1.setText("\n\t\t\t                 See You Again Love\n\t\t\t                   Daniela Marquez\n\n\tEvery morning, the café at the corner of Aurora Street opened at exactly 6:30 a.m., even before the sun fully rose over \nthe city of Calendra. It wasn’t a famous place, nor was it particularly special to anyone except one person Noah Calderon. He always \nsat by the same window seat, always ordered the same black coffee, and always stayed just long enough to watch the world wake up.\nNoah wasn’t waiting for anything in particular, at least that’s what he told himself. But every detail of his routine was built around a memory \nhe refused to let fade. Three years ago, that same seat used to be shared. Her name was Isla Virella, a soft-spoken artist who painted \nmoments instead of things. She used to say that people weren’t meant to be held forever, only remembered gently.\n\n\tThey met by accident two strangers reaching for the last pastry on a rainy afternoon. It turned into shared breakfasts, \nlong conversations about everything and nothing, and quiet walks home under umbrellas too small for two. Isla had a way of making \nsilence feel like a language, and Noah had a way of answering without speaking. It felt effortless, like something that had always existed \nbut was only now being noticed. But life didn’t ask for permission when it decided to change things. Isla was offered a residency abroad \nfor her art an opportunity she couldn’t refuse. Noah never asked her to stay. He only asked her to promise one thing before she left: “If \nwe’re meant to find each other again, we will.” She smiled, touched his hand, and said, “Then see you again, love.” \n\n\tAfter she left, the café seat became his habit, not because he expected her to walk through the door, but because it was \nthe only place that still felt like her. Time moved forward in the city, but for Noah, it lingered somewhere between mornings and memory. \nHe stopped expecting messages, stopped checking old photos, but never stopped sitting by that window. One morning, the café was \nunusually crowded. Noah almost didn’t notice her at first she stood near the counter, sketchbook tucked under her arm, hair slightly longer\neyes carrying the same quiet depth he remembered too well. But something was different. She didn’t look like someone passing through. \nShe looked like someone who had returned. \n\n\tWhen their eyes met, the world didn’t slow down dramatically like in stories. Instead, it simply felt… still. Isla smiled first, \nunsure but certain at the same time. “You still come here,” she said softly, like it was something she already knew. Noah couldn’t answer \nright away. Three years of silence suddenly felt heavier than words. Finally, he nodded. “You said we’d find each other again.” She stepped \ncloser, holding her sketchbook tighter. “I wasn’t sure if you’d still be waiting.” “I wasn’t waiting,” he said honestly, then paused. “I was \nremembering.” That made her smile small, bittersweet, familiar. She opened her sketchbook and showed him pages filled with places \nshe had been, people she had drawn, moments she had collected. Noah looked at her, really looked at her, and realized something \nsimple but important: some things don’t survive distance the same way they survive change. And sometimes, survival looks like finding \nyour way back without knowing if there’s still a place for you.\n\n\tBut tucked between them were sketches of a café window, always the same one. Always empty. Always waiting. “I thought \nabout coming back a hundred times,” she admitted. “But I wasn’t sure if some things survive distance.” ");
        jScrollPane1.setViewportView(jTextArea1);

        jPanel1.add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 10, 876, 636));

        jLabel5.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/1r2 (1).png"))); // NOI18N
        jPanel1.add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(953, 85, 123, -1));

        lblBookTitle.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        lblBookTitle.setText("BORROW");
        lblBookTitle.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                lblBookTitleActionPerformed(evt);
            }
        });
        jPanel1.add(lblBookTitle, new org.netbeans.lib.awtextra.AbsoluteConstraints(941, 266, 135, -1));

        jButton2.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        jButton2.setText("REVIEWS");
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });
        jPanel1.add(jButton2, new org.netbeans.lib.awtextra.AbsoluteConstraints(941, 300, 135, -1));

        btnmarkasread.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        btnmarkasread.setText("MARK AS READ");
        btnmarkasread.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnmarkasreadActionPerformed(evt);
            }
        });
        jPanel1.add(btnmarkasread, new org.netbeans.lib.awtextra.AbsoluteConstraints(941, 334, 135, -1));

        btnfavorites.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        btnfavorites.setText("FAVORITES");
        btnfavorites.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnfavoritesActionPerformed(evt);
            }
        });
        jPanel1.add(btnfavorites, new org.netbeans.lib.awtextra.AbsoluteConstraints(941, 368, 135, -1));

        jButton3.setText("BACK");
        jButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton3ActionPerformed(evt);
            }
        });
        jPanel1.add(jButton3, new org.netbeans.lib.awtextra.AbsoluteConstraints(960, 30, -1, -1));

        getContentPane().add(jPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(32, 14, -1, -1));

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void lblBookTitleActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_lblBookTitleActionPerformed
        lblBookTitle.setText("BORROWED");
    lblBookTitle.setEnabled(false);
    
   
    try {
       
        java.sql.Connection conn = java.sql.DriverManager.getConnection("jdbc:mysql://localhost:3306/library_system", "root", "");
        
      
        String sql = "UPDATE books SET status = 'BORROWED' WHERE book_title = 'See You Again Love'";
        
        java.sql.PreparedStatement pst = conn.prepareStatement(sql);
        pst.executeUpdate(); 
        
        conn.close();
    } catch (Exception e) {
      
        System.out.println("Database Update Error: " + e.getMessage());
    }
        borrow_form bf = new borrow_form(); 
    
   
    bf.txtBookTitle.setText("See You Again Love"); 
    bf.setVisible(true);
    }//GEN-LAST:event_lblBookTitleActionPerformed

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
    String bookTitle = "See You Again Love"; 

  
    REVIEW_BOOK rf = new REVIEW_BOOK();
    rf.lblReviewBookTitle.setText("SHARE YOUR THOUGHTS");
    rf.txtBookTitle.setText(bookTitle);
    
    rf.setVisible(true);
    }//GEN-LAST:event_jButton2ActionPerformed

    private void btnmarkasreadActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnmarkasreadActionPerformed
        javax.swing.JOptionPane.showMessageDialog(this, 
        "You have successfully marked 'See You Again Love' as Read!", 
        "Success", 
        javax.swing.JOptionPane.INFORMATION_MESSAGE);

    
    btnmarkasread.setText("COMPLETED");
    btnmarkasread.setEnabled(false);
    
    
    btnmarkasread.setBackground(new java.awt.Color(153, 255, 153)); 
    }//GEN-LAST:event_btnmarkasreadActionPerformed

    private void btnfavoritesActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnfavoritesActionPerformed
        javax.swing.JOptionPane.showMessageDialog(this, 
        "'See You Again Love' has been added to your Favorites!", 
        "Added to Favorites", 
        javax.swing.JOptionPane.INFORMATION_MESSAGE);

    
    btnfavorites.setText("❤ FAVORITED");
    
   
    btnfavorites.setBackground(new java.awt.Color(255, 204, 204));
    btnfavorites.setEnabled(false);
    }//GEN-LAST:event_btnfavoritesActionPerformed

    private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton3ActionPerformed
       DASHBOARD3 dashboardPage = new DASHBOARD3("1");
    dashboardPage.setVisible(true);
    
   
    this.dispose();
    }//GEN-LAST:event_jButton3ActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ReflectiveOperationException | javax.swing.UnsupportedLookAndFeelException ex) {
            logger.log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(() -> new BOOK7().setVisible(true));
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnfavorites;
    private javax.swing.JButton btnmarkasread;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton3;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTextArea jTextArea1;
    private javax.swing.JButton lblBookTitle;
    // End of variables declaration//GEN-END:variables
}
