package ROMANCE;
import ticaro.ui.DASHBOARD3;
import ticaro.ui.REVIEW_BOOK;
import ticaro.ui.borrow_form;

/**
 *
 * @author Alethea Jae
 */
public class BOOK4 extends javax.swing.JFrame {
    
    private static final java.util.logging.Logger logger = java.util.logging.Logger.getLogger(BOOK4.class.getName());

    /**
     * Creates new form BOOK4
     */
    public BOOK4() {
        initComponents();
    checkBookStatus();
    }
    
private void checkBookStatus() {
    try {
        // 1. Connect to your database (using your 'coffee_pos' or 'library_db')
        java.sql.Connection conn = java.sql.DriverManager.getConnection("jdbc:mysql://localhost:3306/library_system", "root", "");
        
        // 2. Query to check the status of this specific book
        String sql = "SELECT status FROM books WHERE book_title = 'UNTIL WE MET AGAIN BY: NAGISA FURUYA'";
        java.sql.PreparedStatement pst = conn.prepareStatement(sql);
        java.sql.ResultSet rs = pst.executeQuery();

        if (rs.next()) {
            String status = rs.getString("status");
            
            // 3. If the book is borrowed, change the button automatically
            if (status.equalsIgnoreCase("BORROWED")) {
                lblBookTitle.setText("BORROWED");
                lblBookTitle.setEnabled(false);
                lblBookTitle.setBackground(java.awt.Color.GRAY);
            } else {
                // If it was returned, it stays/becomes AVAILABLE
                lblBookTitle.setText("BORROW");
                lblBookTitle.setEnabled(true);
                lblBookTitle.setBackground(new java.awt.Color(255, 255, 255));
            }
        }
        conn.close();
    } catch (Exception e) {
        System.out.println("Error: " + e.getMessage());
    }
}
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTextArea1 = new javax.swing.JTextArea();
        jLabel5 = new javax.swing.JLabel();
        lblBookTitle = new javax.swing.JButton();
        jButton2 = new javax.swing.JButton();
        btnmarkasread = new javax.swing.JButton();
        btnfavorites = new javax.swing.JButton();
        jButton3 = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel1.setBackground(new java.awt.Color(255, 255, 255));
        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jTextArea1.setColumns(20);
        jTextArea1.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jTextArea1.setRows(5);
        jTextArea1.setText("\n\t\t\t                Until We Met Again\n\t\t\t                     Nagisa Furuya\n\n\tIn the quiet coastal town of San Ilaya, where the sea always seemed to whisper forgotten promises, lived a girl named \nMara. She was known for sitting by the old lighthouse every afternoon, writing letters she never sent. People in town often said she was \nwaiting for someone, though no one knew exactly who. The truth was, Mara herself wasn’t entirely sure anymore only that there was \nsomeone she once promised to meet again, under the same sky that once held their dreams. Years earlier, when Mara was sixteen, she met\na boy named Elias during a summer storm. He had just moved to San Ilaya with his father, and their first encounter was anything but \nordinary he had gotten stranded in the rain near the lighthouse, and she offered him her umbrella without saying a word.\n\n\tThat small act turned into daily conversations, shared sunsets, and dreams written in the sand. Elias wanted to become a \nmarine biologist and travel the world studying oceans, while Mara dreamed of becoming a writer who would one day tell their story. But \nlife, as it often does, changed its course. Elias’s father received a job offer abroad, and they had to leave suddenly. On their last day together\nElias promised her something as they stood under the flickering lighthouse light: “If we’re meant to find each other, we will no matter how\nlong it takes. Until we met again.” Mara laughed softly at his broken grammar, but she held onto the words like they were the only thing \nkeeping her steady. \n\n\tYears passed. Letters were written but never sent. Seasons changed, and the lighthouse aged with her memories. Mara \nstopped expecting anything, yet she never stopped waiting. Every evening, she still visited the shore, tracing their old footprints in the \nsand that the waves refused to keep. The town moved on, but she stayed anchored to a promise that no one else could see. One stormy \nevening, when the sky roared louder than her thoughts, a familiar figure appeared at the edge of the shore. He was older now, with eyes \nthat still carried the same restless calm. Elias had returned not as a boy chasing dreams, but as a man who had traveled oceans only to \nrealize one truth: some places and people are not meant to be left behind. He had come back to find her, guided by stories he had never \nstopped telling himself. \n\n\tThey stood there for a long time without speaking, the waves filling the silence between them. When he finally said her name,\nit sounded like time had folded itself back into place. Mara smiled through tears she didn’t realize she was holding. The years didn’t disappear, \nbut they softened, like the sea smoothing sharp stones. And just like that, beneath the same lighthouse that once watched them part, they \ndidn’t ask what came next. They only understood one thing that some promises are not about timing, but about return. And after all the waiting, \nall the silence, all the distance between then and now, they finally became what they once were meant to be. ");
        jScrollPane1.setViewportView(jTextArea1);

        jPanel1.add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(18, 16, 880, 636));

        jLabel5.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/1r5 (1).png"))); // NOI18N
        jPanel1.add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(953, 85, 123, -1));

        lblBookTitle.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        lblBookTitle.setText("BORROW");
        lblBookTitle.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                lblBookTitleActionPerformed(evt);
            }
        });
        jPanel1.add(lblBookTitle, new org.netbeans.lib.awtextra.AbsoluteConstraints(941, 271, 135, -1));

        jButton2.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        jButton2.setText("REVIEWS");
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });
        jPanel1.add(jButton2, new org.netbeans.lib.awtextra.AbsoluteConstraints(941, 305, 135, -1));

        btnmarkasread.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        btnmarkasread.setText("MARK AS READ");
        btnmarkasread.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnmarkasreadActionPerformed(evt);
            }
        });
        jPanel1.add(btnmarkasread, new org.netbeans.lib.awtextra.AbsoluteConstraints(941, 339, 135, -1));

        btnfavorites.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        btnfavorites.setText("FAVORITES");
        btnfavorites.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnfavoritesActionPerformed(evt);
            }
        });
        jPanel1.add(btnfavorites, new org.netbeans.lib.awtextra.AbsoluteConstraints(941, 373, 135, -1));

        jButton3.setText("BACK");
        jButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton3ActionPerformed(evt);
            }
        });
        jPanel1.add(jButton3, new org.netbeans.lib.awtextra.AbsoluteConstraints(960, 40, -1, -1));

        getContentPane().add(jPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(6, 6, -1, -1));

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void lblBookTitleActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_lblBookTitleActionPerformed
        lblBookTitle.setText("BORROWED");
    lblBookTitle.setEnabled(false);
    
   
    try {
       
        java.sql.Connection conn = java.sql.DriverManager.getConnection("jdbc:mysql://localhost:3306/library_system", "root", "");
        
      
        String sql = "UPDATE books SET status = 'BORROWED' WHERE book_title = 'UNTIL WE MET AGAIN BY: NAGISA FURUYA'";
        
        java.sql.PreparedStatement pst = conn.prepareStatement(sql);
        pst.executeUpdate(); 
        
        conn.close();
    } catch (Exception e) {
      
        System.out.println("Database Update Error: " + e.getMessage());
    }
        borrow_form bf = new borrow_form(); 
    
   
    bf.txtBookTitle.setText("UNTIL WE MET AGAIN BY: NAGISA FURUYA"); 
    bf.setVisible(true);
    }//GEN-LAST:event_lblBookTitleActionPerformed

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
       String bookTitle = "UNTIL WE MET AGAIN BY: NAGISA FURUYA"; 

  
    REVIEW_BOOK rf = new REVIEW_BOOK();
    rf.lblReviewBookTitle.setText("SHARE YOUR THOUGHTS");
    rf.txtBookTitle.setText(bookTitle);
    
    rf.setVisible(true);
    }//GEN-LAST:event_jButton2ActionPerformed

    private void btnmarkasreadActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnmarkasreadActionPerformed
      javax.swing.JOptionPane.showMessageDialog(this, 
        "You have successfully marked 'UNTIL WE MET AGAIN BY: NAGISA FURUYA' as Read!", 
        "Success", 
        javax.swing.JOptionPane.INFORMATION_MESSAGE);

    
    btnmarkasread.setText("COMPLETED");
    btnmarkasread.setEnabled(false);
    
    
    btnmarkasread.setBackground(new java.awt.Color(153, 255, 153)); 
    }//GEN-LAST:event_btnmarkasreadActionPerformed

    private void btnfavoritesActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnfavoritesActionPerformed
       javax.swing.JOptionPane.showMessageDialog(this, 
        "'UNTIL WE MET AGAIN BY: NAGISA FURUYA' has been added to your Favorites!", 
        "Added to Favorites", 
        javax.swing.JOptionPane.INFORMATION_MESSAGE);

    
    btnfavorites.setText("❤ FAVORITED");
    
   
    btnfavorites.setBackground(new java.awt.Color(255, 204, 204));
    btnfavorites.setEnabled(false);
    }//GEN-LAST:event_btnfavoritesActionPerformed

    private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton3ActionPerformed
          DASHBOARD3 dashboardPage = new DASHBOARD3("1");
    dashboardPage.setVisible(true);
    
   
    this.dispose();
    }//GEN-LAST:event_jButton3ActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ReflectiveOperationException | javax.swing.UnsupportedLookAndFeelException ex) {
            logger.log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(() -> new BOOK4().setVisible(true));
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnfavorites;
    private javax.swing.JButton btnmarkasread;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton3;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTextArea jTextArea1;
    private javax.swing.JButton lblBookTitle;
    // End of variables declaration//GEN-END:variables
}
