package ROMANCE;
import ticaro.ui.DASHBOARD3;
import ticaro.ui.REVIEW_BOOK;
import ticaro.ui.borrow_form;
/**
 *
 * @author Alethea Jae
 */
public class BOOK5 extends javax.swing.JFrame {
    
    private static final java.util.logging.Logger logger = java.util.logging.Logger.getLogger(BOOK5.class.getName());

    /**
     * Creates new form BOOK5
     */
    public BOOK5() {
        initComponents();
   checkBookStatus();
    }
    
private void checkBookStatus() {
    try {
        // 1. Connect to your database (using your 'coffee_pos' or 'library_db')
        java.sql.Connection conn = java.sql.DriverManager.getConnection("jdbc:mysql://localhost:3306/library_system", "root", "");
        
        // 2. Query to check the status of this specific book
        String sql = "SELECT status FROM books WHERE book_title = 'A BILLIONARE'S IRE ROMANCE'";
        java.sql.PreparedStatement pst = conn.prepareStatement(sql);
        java.sql.ResultSet rs = pst.executeQuery();

        if (rs.next()) {
            String status = rs.getString("status");
            
            // 3. If the book is borrowed, change the button automatically
            if (status.equalsIgnoreCase("BORROWED")) {
                lblBookTitle.setText("BORROWED");
                lblBookTitle.setEnabled(false);
                lblBookTitle.setBackground(java.awt.Color.GRAY);
            } else {
                // If it was returned, it stays/becomes AVAILABLE
                lblBookTitle.setText("BORROW");
                lblBookTitle.setEnabled(true);
                lblBookTitle.setBackground(new java.awt.Color(255, 255, 255));
            }
        }
        conn.close();
    } catch (Exception e) {
        System.out.println("Error: " + e.getMessage());
    }
}
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTextArea1 = new javax.swing.JTextArea();
        jLabel5 = new javax.swing.JLabel();
        lblBookTitle = new javax.swing.JButton();
        jButton2 = new javax.swing.JButton();
        btnmarkasread = new javax.swing.JButton();
        btnfavorites = new javax.swing.JButton();
        jButton3 = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel1.setBackground(new java.awt.Color(255, 255, 255));
        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jTextArea1.setColumns(20);
        jTextArea1.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jTextArea1.setRows(5);
        jTextArea1.setText("\n\t\t\t           A Billionaire’s Ire Romance\n\t\t\t                    Celeste Navarro\n\n\tAdrian Vale was a name that carried weight in every boardroom across the country. At twenty-nine, he was already the \nyoungest CEO in the Vale Holdings empire, a billion-dollar conglomerate built from discipline, control, and an emotionless approach to \nbusiness. To the public, he was flawless sharp suit, sharper tongue, and a reputation for never losing. But behind closed doors, Adrian \nwas known for something else entirely: his temper. Cold, calculated anger that could silence an entire room without him ever raising his \nvoice. \n\n\tLira Santos, on the other hand, lived in a world that barely brushed against his. She was a scholarship student working \npart-time as an architectural intern at one of Vale Holdings’ partnered firms. She believed in designs that breathed life into cities, not just \nsteel and glass towers that scraped the sky for profit. When she was assigned to assist in a major Vale project, she didn’t expect her life to \nintersect with the man everyone feared. Their first meeting was disastrous. Lira accidentally challenged one of Adrian’s design decisions \nduring a review meeting, not knowing he was the final decision-maker in the room. The silence that followed was suffocating. Everyone \nexpected her dismissal. Instead, Adrian simply stared at her, his eyes sharp enough to cut through confidence. “You think you know better?”\n\n\the asked quietly. And just like that, she became the only person who dared to answer him honestly instead of fearfully.\nWhat started as conflict slowly turned into reluctant collaboration. Lira’s ideas, though unconventional, began improving his projects in \nways he couldn’t ignore. Adrian hated how she made him question things he never thought needed questioning. And Lira hated how, \nbeneath his cold arrogance, there were rare moments where he listened not as a billionaire, but as a man trying not to feel anything at all.\nThe more time they spent working together, the more cracks formed in Adrian’s carefully built world. He found himself waiting for her \nopinions, watching how she tucked stray hair behind her ear when she was focused, and feeling irritation whenever someone else agreed \nwith her too quickly. Lira, meanwhile, discovered that the “monster CEO” the world described wasn’t entirely true just deeply wounded, \nshaped by expectations he never chose.\n\n\tBut love in their world was never simple. Adrian’s business empire was under threat, and alliances were being formed \nthrough arranged corporate ties one of which involved a powerful merger that required him to be engaged to someone else. Lira found \nout not from him, but from headlines. That moment shattered everything she thought she was building with him. When she tried to step \naway, Adrian did something he had never done in his entire life he lost control. Not in anger this time, but in desperation. He admitted \nwhat he had been denying since the beginning: that for the first time, he didn’t want to win if it meant losing her. But love didn’t erase \nobligations, and power didn’t bend easily to emotion.\n\n\tIn the end, Adrian made a choice that shocked both his world and hers. He walked away from the engagement, risked \nparts of his empire, and faced consequences he had spent his whole life avoiding. Not because Lira demanded it but because for once, \nhe wanted something that wasn’t built on control. Months later, Lira stood on the rooftop of a completed Vale project a design she \nhelped create, now alive with light and movement. Adrian appeared behind her, no longer untouchable, no longer untamed by rage, \nbut finally human in a way money could never define. He didn’t promise her the world. He simply said, “I don’t need to own everything \nanymore. Just don’t leave.”");
        jScrollPane1.setViewportView(jTextArea1);

        jPanel1.add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(18, 16, 880, 636));

        jLabel5.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/1r4 (1).png"))); // NOI18N
        jPanel1.add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(953, 85, 123, -1));

        lblBookTitle.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        lblBookTitle.setText("BORROW");
        lblBookTitle.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                lblBookTitleActionPerformed(evt);
            }
        });
        jPanel1.add(lblBookTitle, new org.netbeans.lib.awtextra.AbsoluteConstraints(941, 275, 135, -1));

        jButton2.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        jButton2.setText("REVIEWS");
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });
        jPanel1.add(jButton2, new org.netbeans.lib.awtextra.AbsoluteConstraints(941, 309, 135, -1));

        btnmarkasread.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        btnmarkasread.setText("MARK AS READ");
        btnmarkasread.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnmarkasreadActionPerformed(evt);
            }
        });
        jPanel1.add(btnmarkasread, new org.netbeans.lib.awtextra.AbsoluteConstraints(941, 343, 135, -1));

        btnfavorites.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        btnfavorites.setText("FAVORITES");
        btnfavorites.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnfavoritesActionPerformed(evt);
            }
        });
        jPanel1.add(btnfavorites, new org.netbeans.lib.awtextra.AbsoluteConstraints(941, 377, 135, -1));

        jButton3.setText("BACK");
        jButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton3ActionPerformed(evt);
            }
        });
        jPanel1.add(jButton3, new org.netbeans.lib.awtextra.AbsoluteConstraints(970, 30, -1, -1));

        getContentPane().add(jPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(32, 14, -1, -1));

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void lblBookTitleActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_lblBookTitleActionPerformed
        lblBookTitle.setText("BORROWED");
    lblBookTitle.setEnabled(false);
    
   
    try {
       
        java.sql.Connection conn = java.sql.DriverManager.getConnection("jdbc:mysql://localhost:3306/library_system", "root", "");
        
      
        String sql = "UPDATE books SET status = 'BORROWED' WHERE book_title = 'A BILLIONARE'S IRE ROMANCE'";
        
        java.sql.PreparedStatement pst = conn.prepareStatement(sql);
        pst.executeUpdate(); 
        
        conn.close();
    } catch (Exception e) {
      
        System.out.println("Database Update Error: " + e.getMessage());
    }
        borrow_form bf = new borrow_form(); 
    
   
    bf.txtBookTitle.setText("A BILLIONARE'S IRE ROMANCE"); 
    bf.setVisible(true);
    }//GEN-LAST:event_lblBookTitleActionPerformed

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
        String bookTitle = "A BILLIONARE'S IRE ROMANCE"; 

  
    REVIEW_BOOK rf = new REVIEW_BOOK();
    rf.lblReviewBookTitle.setText("SHARE YOUR THOUGHTS");
    rf.txtBookTitle.setText(bookTitle);
    
    rf.setVisible(true);

    }//GEN-LAST:event_jButton2ActionPerformed

    private void btnmarkasreadActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnmarkasreadActionPerformed
        javax.swing.JOptionPane.showMessageDialog(this, 
        "You have successfully marked 'A BILLIONARE'S IRE ROMANCE' as Read!", 
        "Success", 
        javax.swing.JOptionPane.INFORMATION_MESSAGE);

    
    btnmarkasread.setText("COMPLETED");
    btnmarkasread.setEnabled(false);
    
    
    btnmarkasread.setBackground(new java.awt.Color(153, 255, 153)); 
    }//GEN-LAST:event_btnmarkasreadActionPerformed

    private void btnfavoritesActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnfavoritesActionPerformed
      javax.swing.JOptionPane.showMessageDialog(this, 
        "'A BILLIONARE'S IRE ROMANCE' has been added to your Favorites!", 
        "Added to Favorites", 
        javax.swing.JOptionPane.INFORMATION_MESSAGE);

    
    btnfavorites.setText("❤ FAVORITED");
    
   
    btnfavorites.setBackground(new java.awt.Color(255, 204, 204));
    btnfavorites.setEnabled(false);
    }//GEN-LAST:event_btnfavoritesActionPerformed

    private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton3ActionPerformed
        DASHBOARD3 dashboardPage = new DASHBOARD3("1");
    dashboardPage.setVisible(true);
    
   
    this.dispose();
    }//GEN-LAST:event_jButton3ActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ReflectiveOperationException | javax.swing.UnsupportedLookAndFeelException ex) {
            logger.log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(() -> new BOOK5().setVisible(true));
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnfavorites;
    private javax.swing.JButton btnmarkasread;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton3;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTextArea jTextArea1;
    private javax.swing.JButton lblBookTitle;
    // End of variables declaration//GEN-END:variables
}
