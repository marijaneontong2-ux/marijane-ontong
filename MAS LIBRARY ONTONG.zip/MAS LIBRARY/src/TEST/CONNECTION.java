package TEST;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class CONNECTION{
    public static Connection connect() {
        try {
            // Ensure you have added the MySQL JDBC Driver to your Libraries
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/library_db", "root", "");
            return conn;
        } catch (Exception e) {
            System.out.println("Connection Failed: " + e);
            return null;
        }
    }
}