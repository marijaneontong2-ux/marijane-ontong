package TEST;

import javax.swing.table.DefaultTableModel;
import java.sql.*;
import javax.swing.JOptionPane;
import ticaro.ui.CONNECTION;

public class BORROWED_BOOKS extends javax.swing.JPanel {

    public String currentStudentId;

public BORROWED_BOOKS(String sid) {
    initComponents();
    this.currentStudentId = sid; 
    loadBorrowedStatus(sid);     
}

   public void loadBorrowedStatus(String loggedInStudentId) {
    DefaultTableModel model = (DefaultTableModel) jTable1.getModel(); // Ensure this matches your table variable name
    model.setRowCount(0); // Clear existing data

    try {
        // Connect to your database
        java.sql.Connection con = ticaro.ui.CONNECTION.getConnection();

       String sql = "SELECT book_title, borrow_date, due_date, status, penalty " +
             "FROM borrowed_books WHERE student_id = ? AND status = 'Pending'";

java.sql.PreparedStatement pst = con.prepareStatement(sql);

pst.setString(1, loggedInStudentId);
       
      
        
        java.sql.ResultSet rs = pst.executeQuery();

        while (rs.next()) {
            Object[] row = {
                rs.getString("book_title"),
                rs.getDate("borrow_date"),
                rs.getDate("due_date"),
                rs.getString("status"),
                "₱" + rs.getDouble("penalty") // Formatting the penalty with currency
            };
            model.addRow(row);
        }
        
        con.close();
    } catch (Exception e) {
        System.out.println("Error Loading Status: " + e.getMessage());
        e.printStackTrace();
    }
}
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jScrollPane1 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        jLabel1 = new javax.swing.JLabel();
        jPanel1 = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();

        setBackground(new java.awt.Color(51, 51, 51));
        setForeground(new java.awt.Color(255, 255, 255));
        setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null}
            },
            new String [] {
                "BOOK TITLE ", "BORROW DATE", "DUE DATE", "STATUS", "PENALTY"
            }
        ));
        jTable1.setName(""); // NOI18N
        jTable1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                jTable1MouseEntered(evt);
            }
        });
        jScrollPane1.setViewportView(jTable1);

        add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(130, 160, 980, 480));

        jLabel1.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 255, 255));
        jLabel1.setText("MY STATUS TRACKING");
        add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 90, 210, 30));

        jPanel1.setBackground(new java.awt.Color(0, 0, 0));
        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel2.setFont(new java.awt.Font("Times New Roman", 1, 24)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(255, 255, 255));
        jLabel2.setText("MY BORROWED BOOKS STATUS");
        jPanel1.add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(360, 30, 410, -1));

        add(jPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 1400, 80));
    }// </editor-fold>//GEN-END:initComponents

    private void jTable1MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jTable1MouseEntered
        // TODO add your handling code here:
    }//GEN-LAST:event_jTable1MouseEntered


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    public javax.swing.JTable jTable1;
    // End of variables declaration//GEN-END:variables
}
