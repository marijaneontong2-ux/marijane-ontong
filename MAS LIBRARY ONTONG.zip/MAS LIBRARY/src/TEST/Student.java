package TEST;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
/**
 *
 * @author MARY GANE
 */
public class Student extends javax.swing.JPanel {
    String currentUserID; // This stores who is logged in

    public Student (String studentID) {
        initComponents();
        this.currentUserID = studentID;
       showBorrowedBooks(studentID);
    }

public void showBorrowedBooks(String studentID) {
    DefaultTableModel model = (DefaultTableModel) tblBorrowed.getModel();
    model.setRowCount(0); // Clear existing data

    try {
        Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/library_system", "root", "");
        
        // This query matches your 'borrowed_books' table structure exactly!
        String query = "SELECT book_title, borrow_date, due_date, status FROM borrowed_books WHERE student_id = ?";
        
        PreparedStatement pst = con.prepareStatement(query);
        pst.setString(1, studentID);
        
        ResultSet rs = pst.executeQuery();
        
        while(rs.next()) {
            String title = rs.getString("book_title");
            String bDate = rs.getString("borrow_date");
            String dDate = rs.getString("due_date");
            String status = rs.getString("status");
            
            // This adds the row to your "Currently Borrowed" table
            model.addRow(new Object[]{title, bDate, dDate, status});
        }
        con.close();
    } catch (Exception e) {
        e.printStackTrace();
    }
}
   // Inside Student.java
private void displayStudentName(String currentStudentId) {

    try {

        Connection conn = DriverManager.getConnection(
        "jdbc:mysql://localhost:3306/library_system",
        "root",
        "");

        String sql =
        "SELECT first_name, last_name FROM users WHERE student_id=?";

        PreparedStatement pst = conn.prepareStatement(sql);

        pst.setString(1, currentStudentId);

        ResultSet rs = pst.executeQuery();

        if(rs.next()) {

            String fullname =
            rs.getString("first_name") + " " +
            rs.getString("last_name");

            welcomeLabel.setText(
            "WELCOME, " + fullname.toUpperCase());

        } else {

            welcomeLabel.setText("WELCOME");

        }

        conn.close();

    } catch(Exception e) {

        JOptionPane.showMessageDialog(null, e);

    }
}
public void loadFavoriteBooks(String currentStudentId) {

    DefaultTableModel model =
    (DefaultTableModel) tblFavorites.getModel();

    model.setRowCount(0);

    try {

        Connection conn = DriverManager.getConnection(
        "jdbc:mysql://localhost:3306/library_system",
        "root",
        "");

        String query =
        "SELECT book_title FROM favorite_books WHERE student_id=?";

        PreparedStatement pst = conn.prepareStatement(query);

        pst.setString(1, currentStudentId);

        ResultSet rs = pst.executeQuery();

        while(rs.next()) {

            String title = rs.getString("book_title");

            model.addRow(new Object[]{title});
        }

        conn.close();

    } catch(Exception e) {

        JOptionPane.showMessageDialog(null,
        "Favorite Error: " + e.getMessage());
    }
}
public void loadReadBooks(String currentStudentId) {
    DefaultTableModel model = (DefaultTableModel) tblMarkRead.getModel();
    model.setRowCount(0); 

    try (Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/library_system", "root", "")) {
        // Double check your table name in MySQL! Is it 'mark_read' or 'completed_books'?
        String query = "SELECT book_title FROM mark_read WHERE student_id=?";
        PreparedStatement pst = conn.prepareStatement(query);
        pst.setString(1, currentStudentId);
        ResultSet rs = pst.executeQuery();

        while(rs.next()) {
            model.addRow(new Object[]{rs.getString("book_title")});
        }
    } catch(Exception e) {
        e.printStackTrace();
    }
}
public void loadNotifications(String currentStudentId) {

    DefaultTableModel model =
    (DefaultTableModel) jTable4.getModel();

    model.setRowCount(0);

    try {

        Connection conn = DriverManager.getConnection(
        "jdbc:mysql://localhost:3306/library_system",
        "root",
        "");

        String query =
        "SELECT message FROM notifications WHERE student_id=?";

        PreparedStatement pst = conn.prepareStatement(query);

        pst.setString(1, currentStudentId);

        ResultSet rs = pst.executeQuery();

        while(rs.next()) {

            String msg = rs.getString("message");

            model.addRow(new Object[]{msg});
        }

        conn.close();

    } catch(Exception e) {

        JOptionPane.showMessageDialog(null,
        "Notification Error: " + e.getMessage());
    }
}
/**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jLabel4 = new javax.swing.JLabel();
        welcomeLabel = new javax.swing.JLabel();
        JLabel = new javax.swing.JLabel();
        jScrollPane5 = new javax.swing.JScrollPane();
        tblFavorites = new javax.swing.JTable();
        jScrollPane6 = new javax.swing.JScrollPane();
        tblBorrowed = new javax.swing.JTable();
        jScrollPane7 = new javax.swing.JScrollPane();
        tblMarkRead = new javax.swing.JTable();
        jScrollPane8 = new javax.swing.JScrollPane();
        jTable4 = new javax.swing.JTable();

        setBackground(new java.awt.Color(51, 51, 51));
        setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel1.setBackground(new java.awt.Color(255, 255, 255));
        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel4.setBackground(new java.awt.Color(0, 0, 0));
        jLabel4.setFont(new java.awt.Font("Segoe UI", 3, 24)); // NOI18N
        jLabel4.setText("WELCOME");
        jPanel1.add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 150, -1, -1));

        welcomeLabel.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        welcomeLabel.setText("WELCOME,");
        jPanel1.add(welcomeLabel, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 10, -1, -1));

        JLabel.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                JLabelMouseClicked(evt);
            }
        });
        jPanel1.add(JLabel, new org.netbeans.lib.awtextra.AbsoluteConstraints(140, 10, 280, 40));

        add(jPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 1140, 60));

        tblFavorites.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null},
                {null},
                {null},
                {null}
            },
            new String [] {
                "FAVORITE BOOKS"
            }
        ));
        jScrollPane5.setViewportView(tblFavorites);

        add(jScrollPane5, new org.netbeans.lib.awtextra.AbsoluteConstraints(110, 460, 380, 270));

        tblBorrowed.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null},
                {null},
                {null},
                {null}
            },
            new String [] {
                "MY CURRENTLY BORROWED BOOKS"
            }
        ));
        jScrollPane6.setViewportView(tblBorrowed);

        add(jScrollPane6, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 130, 380, 270));

        tblMarkRead.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null},
                {null},
                {null},
                {null}
            },
            new String [] {
                "MARK AS READ BOOK"
            }
        ));
        jScrollPane7.setViewportView(tblMarkRead);

        add(jScrollPane7, new org.netbeans.lib.awtextra.AbsoluteConstraints(540, 460, 380, 270));

        jTable4.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null},
                {null},
                {null},
                {null}
            },
            new String [] {
                "NOTIFICATIONS"
            }
        ));
        jScrollPane8.setViewportView(jTable4);

        add(jScrollPane8, new org.netbeans.lib.awtextra.AbsoluteConstraints(540, 130, 380, 270));
    }// </editor-fold>//GEN-END:initComponents

    private void JLabelMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_JLabelMouseClicked


    }//GEN-LAST:event_JLabelMouseClicked


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel JLabel;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane5;
    private javax.swing.JScrollPane jScrollPane6;
    private javax.swing.JScrollPane jScrollPane7;
    private javax.swing.JScrollPane jScrollPane8;
    public javax.swing.JTable jTable4;
    public javax.swing.JTable tblBorrowed;
    public javax.swing.JTable tblFavorites;
    public javax.swing.JTable tblMarkRead;
    public javax.swing.JLabel welcomeLabel;
    // End of variables declaration//GEN-END:variables
}
