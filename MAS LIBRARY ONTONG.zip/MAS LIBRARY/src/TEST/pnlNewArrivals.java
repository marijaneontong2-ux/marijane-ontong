package TEST;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.awt.Component;
import javax.swing.ImageIcon;
import javax.swing.JPanel;
import javax.swing.JLabel;
import javax.swing.JButton;

/**
 *
 * @author MARY GANE
 */
public class pnlNewArrivals extends javax.swing.JPanel {

    /**
     * Creates new form pnlNewArrivals
     */
   public pnlNewArrivals() {
    initComponents();
    loadBooksFromDatabase();
}

 public void loadBooksFromDatabase() {
    this.removeAll(); 
    // Set a grid for the main panel so the cards stack nicely
    this.setLayout(new java.awt.GridLayout(0, 4, 20, 20));

    try {
        Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/library_system", "root", "");
        String sql = "SELECT * FROM books WHERE is_visible = 1 ORDER BY Id DESC";
        PreparedStatement pst = con.prepareStatement(sql);
        ResultSet rs = pst.executeQuery();

        while (rs.next()) {
            // --- DATA FROM DB ---
            String titleStr = rs.getString("book_title");
            String path = rs.getString("file_path");
            String desc = rs.getString("description");
            String author = rs.getString("author");

            // --- CREATE THE CARD ---
            JPanel card = new JPanel();
            card.setBackground(java.awt.Color.WHITE);
            card.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(204, 204, 204)));
            card.setLayout(new javax.swing.BoxLayout(card, javax.swing.BoxLayout.Y_AXIS));

            // --- IMAGE ---
            JLabel lblImg = new JLabel();
            lblImg.setAlignmentX(Component.CENTER_ALIGNMENT);
            try {
                lblImg.setIcon(new ImageIcon(new ImageIcon(path).getImage().getScaledInstance(150, 180, java.awt.Image.SCALE_SMOOTH)));
            } catch (Exception e) {
                lblImg.setText("No Image");
            }
            
            // --- TITLE ---
            JLabel lblTitle = new JLabel(titleStr);
            lblTitle.setFont(new java.awt.Font("SansSerif", java.awt.Font.BOLD, 14));
            lblTitle.setAlignmentX(Component.CENTER_ALIGNMENT);

            // --- READ BUTTON ---
            JButton btnRead = new JButton("READ");
            btnRead.setAlignmentX(Component.CENTER_ALIGNMENT);
            btnRead.addActionListener(e -> {
                BookDetail detail = new BookDetail(titleStr, author, desc, path);
                detail.setVisible(true);
            });

            // --- ADD ELEMENTS ---
            card.add(javax.swing.Box.createVerticalStrut(10));
            card.add(lblImg);
            card.add(javax.swing.Box.createVerticalStrut(10));
            card.add(lblTitle);
            card.add(javax.swing.Box.createVerticalStrut(10));
            card.add(btnRead);
            card.add(javax.swing.Box.createVerticalStrut(10));

            this.add(card);
        }
        
        this.revalidate();
        this.repaint();

    } catch (Exception e) {
        System.out.println("Database Error: " + e.getMessage());
    }
}
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        pnlContainer = new javax.swing.JPanel();

        setLayout(new java.awt.GridLayout(1, 0));
        add(pnlContainer);
    }// </editor-fold>//GEN-END:initComponents


    // Variables declaration - do not modify//GEN-BEGIN:variables
    public javax.swing.JPanel pnlContainer;
    // End of variables declaration//GEN-END:variables

 
}
