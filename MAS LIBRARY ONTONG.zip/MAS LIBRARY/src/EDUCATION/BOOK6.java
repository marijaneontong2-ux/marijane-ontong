package EDUCATION;
import ticaro.ui.DASHBOARD3;
import ticaro.ui.REVIEW_BOOK;
import ticaro.ui.borrow_form;

/**
 *
 * @author STUDENT
 */
public class BOOK6 extends javax.swing.JFrame {

    /**
     * Creates new form BOOK6
     */
    public BOOK6() {
        initComponents();
   checkBookStatus();
    }
    
private void checkBookStatus() {
    try {
        // 1. Connect to your database (using your 'coffee_pos' or 'library_db')
        java.sql.Connection conn = java.sql.DriverManager.getConnection("jdbc:mysql://localhost:3306/library_system", "root", "");
        
        // 2. Query to check the status of this specific book
        String sql = "SELECT status FROM books WHERE book_title = 'Python Programming for Beginners: A Step-by-Step Guide to Coding'";
        java.sql.PreparedStatement pst = conn.prepareStatement(sql);
        java.sql.ResultSet rs = pst.executeQuery();

        if (rs.next()) {
            String status = rs.getString("status");
            
            // 3. If the book is borrowed, change the button automatically
            if (status.equalsIgnoreCase("BORROWED")) {
                lblBookTitle.setText("BORROWED");
                lblBookTitle.setEnabled(false);
                lblBookTitle.setBackground(java.awt.Color.GRAY);
            } else {
                // If it was returned, it stays/becomes AVAILABLE
                lblBookTitle.setText("BORROW");
                lblBookTitle.setEnabled(true);
                lblBookTitle.setBackground(new java.awt.Color(255, 255, 255));
            }
        }
        conn.close();
    } catch (Exception e) {
        System.out.println("Error: " + e.getMessage());
    }
}
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTextArea1 = new javax.swing.JTextArea();
        jLabel5 = new javax.swing.JLabel();
        lblBookTitle = new javax.swing.JButton();
        BTN_REVIEW = new javax.swing.JButton();
        btnmarkasread = new javax.swing.JButton();
        btnfavorites = new javax.swing.JButton();
        jButton2 = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel1.setBackground(new java.awt.Color(255, 255, 255));
        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jTextArea1.setColumns(20);
        jTextArea1.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jTextArea1.setRows(5);
        jTextArea1.setText("\n\t\t     Python Programming for Beginners: A Step-by-Step Guide to Coding\n\t\t\t                Emmanuel Navarro\n\n\tPython programming has become one of the most popular entry points into the world of coding due to its simplicity, \nreadability, and versatility. Designed with beginners in mind, Python uses a clean and straightforward syntax that closely resembles human \nlanguage, making it easier to understand compared to many other programming languages. This accessibility allows new learners to focus \nmore on logic and problem-solving rather than getting overwhelmed by complicated rules. As a result, Python serves as an ideal starting \npoint for students, aspiring developers, and anyone interested in exploring technology.\n\n\tThe journey into Python begins with understanding its basic structure. A simple Python program can be written in just a \nfew lines, yet it can perform meaningful tasks such as displaying output, performing calculations, or taking user input. Key concepts such \nas variables and data types form the foundation of programming in Python. Variables are used to store data, while data types such as \nintegers, floats, strings, and booleans define the kind of data being handled. Learning how to properly use these elements is essential in \nbuilding functional programs.\n\n\tControl structures are another important aspect of Python programming. These include conditional statements like “if,” \n“elif,” and “else,” which allow programs to make decisions based on certain conditions. Loops, such as “for” and “while,” enable repetitive \nexecution of code, making it easier to handle tasks that require iteration. By mastering these structures, beginners can create programs that \nrespond dynamically to different inputs and situations.\n\n\tFunctions play a crucial role in organizing code and improving its readability. A function is a block of code designed to \nperform a specific task, and it can be reused multiple times throughout a program. This not only reduces repetition but also makes \nprograms easier to maintain and understand. Python also supports modular programming, where code is divided into separate files or \nmodules, allowing for better structure and scalability as projects grow.\n\n\tAs learners progress, they are introduced to more advanced concepts such as lists, dictionaries, and tuples. These data \nstructures allow programmers to store and manage collections of data efficiently. For example, lists can hold multiple values in a single \nvariable, while dictionaries store data in key-value pairs. Understanding how to manipulate these structures is essential for handling real-\nworld data and solving more complex problems.\n\n\tOne of Python’s greatest strengths lies in its vast ecosystem of libraries and frameworks. Beginners can explore tools like \nNumPy for numerical computations, pandas for data analysis, and Matplotlib for data visualization. These libraries extend Python’s \ncapabilities, allowing users to work on projects in fields such as data science, web development, automation, and artificial intelligence. \nEven with minimal coding experience, beginners can create powerful applications using these resources.\n\n\tError handling and debugging are also important skills in Python programming. Mistakes are a natural part of learning, \nand Python provides clear error messages that help identify and fix issues. By learning how to read and understand these messages, \nbeginners can improve their problem-solving skills and develop more reliable programs. Techniques such as using try-except blocks \nallow programmers to handle errors gracefully and prevent programs from crashing unexpectedly.\n\n\tPractical application is key to mastering Python. Beginners are encouraged to work on small projects such as calculators, \nsimple games, or data-processing scripts. These projects reinforce learning and provide hands-on experience in applying concepts. Over \ntime, as confidence grows, learners can move on to more complex projects, building a strong portfolio that showcases their skills.\n\n\tIn conclusion, Python Programming for Beginners provides a solid foundation for anyone entering the world of coding. \nWith its simple syntax, powerful features, and wide range of applications, Python offers an accessible yet comprehensive introduction to \nprogramming. By learning step by step and practicing consistently, beginners can develop the skills needed to create meaningful \nprograms and explore advanced areas of technology. The journey may start with simple lines of code, but it opens the door to endless \npossibilities in the digital world.");
        jScrollPane1.setViewportView(jTextArea1);

        jPanel1.add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(18, 16, 880, 636));

        jLabel5.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/aleng12..png"))); // NOI18N
        jPanel1.add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(953, 85, 123, -1));

        lblBookTitle.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        lblBookTitle.setText("BORROW");
        lblBookTitle.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                lblBookTitleActionPerformed(evt);
            }
        });
        jPanel1.add(lblBookTitle, new org.netbeans.lib.awtextra.AbsoluteConstraints(941, 267, 135, -1));

        BTN_REVIEW.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        BTN_REVIEW.setText("REVIEWS");
        BTN_REVIEW.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BTN_REVIEWActionPerformed(evt);
            }
        });
        jPanel1.add(BTN_REVIEW, new org.netbeans.lib.awtextra.AbsoluteConstraints(941, 301, 135, -1));

        btnmarkasread.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        btnmarkasread.setText("MARK AS READ");
        btnmarkasread.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnmarkasreadActionPerformed(evt);
            }
        });
        jPanel1.add(btnmarkasread, new org.netbeans.lib.awtextra.AbsoluteConstraints(941, 335, 135, -1));

        btnfavorites.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        btnfavorites.setText("FAVORITES");
        btnfavorites.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnfavoritesActionPerformed(evt);
            }
        });
        jPanel1.add(btnfavorites, new org.netbeans.lib.awtextra.AbsoluteConstraints(941, 369, 135, -1));

        jButton2.setText("BACK");
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });
        jPanel1.add(jButton2, new org.netbeans.lib.awtextra.AbsoluteConstraints(980, 30, -1, -1));

        getContentPane().add(jPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(32, 14, -1, -1));

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void lblBookTitleActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_lblBookTitleActionPerformed
         lblBookTitle.setText("BORROWED");
    lblBookTitle.setEnabled(false);
    
   
    try {
       
        java.sql.Connection conn = java.sql.DriverManager.getConnection("jdbc:mysql://localhost:3306/library_system", "root", "");
        
      
        String sql = "UPDATE books SET status = 'BORROWED' WHERE book_title = 'Python Programming for Beginners: A Step-by-Step Guide to Coding'";
        
        java.sql.PreparedStatement pst = conn.prepareStatement(sql);
        pst.executeUpdate(); 
        
        conn.close();
    } catch (Exception e) {
      
        System.out.println("Database Update Error: " + e.getMessage());
    }
        borrow_form bf = new borrow_form(); 
    bf.txtBookTitle.setText("Python Programming for Beginners: A Step-by-Step Guide to Coding"); 
    
  
    bf.setVisible(true);
    }//GEN-LAST:event_lblBookTitleActionPerformed

    private void BTN_REVIEWActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BTN_REVIEWActionPerformed
     String bookTitle = "Python Programming for Beginners: A Step-by-Step Guide to Coding"; 

  
    REVIEW_BOOK rf = new REVIEW_BOOK();
    rf.lblReviewBookTitle.setText("SHARE YOUR THOUGHTS");
    rf.txtBookTitle.setText(bookTitle);
    
    rf.setVisible(true);
    }//GEN-LAST:event_BTN_REVIEWActionPerformed

    private void btnmarkasreadActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnmarkasreadActionPerformed
         javax.swing.JOptionPane.showMessageDialog(this, 
        "You have successfully marked 'Python Programming for Beginners: A Step-by-Step Guide to Coding' as Read!", 
        "Success", 
        javax.swing.JOptionPane.INFORMATION_MESSAGE);

    
    btnmarkasread.setText("COMPLETED");
    btnmarkasread.setEnabled(false);
    
    
    btnmarkasread.setBackground(new java.awt.Color(153, 255, 153)); 
    }//GEN-LAST:event_btnmarkasreadActionPerformed

    private void btnfavoritesActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnfavoritesActionPerformed
        javax.swing.JOptionPane.showMessageDialog(this, 
        "'Python Programming for Beginners: A Step-by-Step Guide to Coding' has been added to your Favorites!", 
        "Added to Favorites", 
        javax.swing.JOptionPane.INFORMATION_MESSAGE);

    
    btnfavorites.setText("❤ FAVORITED");
    
   
    btnfavorites.setBackground(new java.awt.Color(255, 204, 204));
    btnfavorites.setEnabled(false);
    }//GEN-LAST:event_btnfavoritesActionPerformed

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
       DASHBOARD3 dashboardPage = new DASHBOARD3("1");
    dashboardPage.setVisible(true);
    
   
    this.dispose();
    }//GEN-LAST:event_jButton2ActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(BOOK6.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(BOOK6.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(BOOK6.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(BOOK6.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new BOOK6().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton BTN_REVIEW;
    private javax.swing.JButton btnfavorites;
    private javax.swing.JButton btnmarkasread;
    private javax.swing.JButton jButton2;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTextArea jTextArea1;
    private javax.swing.JButton lblBookTitle;
    // End of variables declaration//GEN-END:variables
}
