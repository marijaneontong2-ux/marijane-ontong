package EDUCATION;
import ticaro.ui.DASHBOARD3;
import ticaro.ui.REVIEW_BOOK;
import ticaro.ui.borrow_form;

/**
 *
 * @author STUDENT
 */
public class BOOK5 extends javax.swing.JFrame {

    /**
     * Creates new form BOOK5
     */
    public BOOK5() {
        initComponents();
    checkBookStatus();
    }
    
private void checkBookStatus() {
    try {
        // 1. Connect to your database (using your 'coffee_pos' or 'library_db')
        java.sql.Connection conn = java.sql.DriverManager.getConnection("jdbc:mysql://localhost:3306/library_system", "root", "");
        
        // 2. Query to check the status of this specific book
        String sql = "SELECT status FROM books WHERE book_title = 'Computer Programming: The Language of Innovation'";
        java.sql.PreparedStatement pst = conn.prepareStatement(sql);
        java.sql.ResultSet rs = pst.executeQuery();

        if (rs.next()) {
            String status = rs.getString("status");
            
            // 3. If the book is borrowed, change the button automatically
            if (status.equalsIgnoreCase("BORROWED")) {
                lblBookTitle.setText("BORROWED");
                lblBookTitle.setEnabled(false);
                lblBookTitle.setBackground(java.awt.Color.GRAY);
            } else {
                // If it was returned, it stays/becomes AVAILABLE
                lblBookTitle.setText("BORROW");
                lblBookTitle.setEnabled(true);
                lblBookTitle.setBackground(new java.awt.Color(255, 255, 255));
            }
        }
        conn.close();
    } catch (Exception e) {
        System.out.println("Error: " + e.getMessage());
    }
}
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTextArea1 = new javax.swing.JTextArea();
        jLabel5 = new javax.swing.JLabel();
        lblBookTitle = new javax.swing.JButton();
        btn_REVIEW = new javax.swing.JButton();
        btnmarkasread = new javax.swing.JButton();
        btnfavorites = new javax.swing.JButton();
        jButton2 = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setBackground(new java.awt.Color(255, 255, 255));
        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jTextArea1.setColumns(20);
        jTextArea1.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jTextArea1.setRows(5);
        jTextArea1.setText("\n\t\t             Computer Programming: The Language of Innovation\n\t\t\t                 Jason Alverez\n\n\tComputer programming is the foundation of modern technology, enabling humans to communicate with machines and \ninstruct them to perform specific tasks. At its core, programming is the process of designing, writing, testing, and maintaining code that \nallows computers to solve problems efficiently. From simple calculations to complex systems like artificial intelligence and operating systems, \nprogramming serves as the backbone of nearly every digital innovation in today’s world.\n\n\tThe journey into programming begins with understanding basic concepts such as variables, data types, and control \nstructures. Variables act as containers for storing data, while data types define the kind of information being processed, such as numbers, \ntext, or boolean values. Control structures, including conditional statements and loops, determine the flow of a program. These foundational \nelements allow programmers to create logical sequences that guide a computer in executing tasks step by step.\n\n\tProgramming languages are the tools used to write instructions for computers. Each language has its own syntax and \npurpose, ranging from beginner-friendly languages like Python to more complex ones like C++ and Java. High-level languages are designed \nto be readable and easier to use, while low-level languages provide greater control over hardware. Choosing the right programming \nlanguage depends on the task at hand, whether it involves web development, mobile applications, data analysis, or system programming.\n\n\tOne of the key aspects of programming is problem-solving. Programmers must analyze a problem, break it down into \nsmaller parts, and develop a logical solution. This process often involves creating algorithms, which are step-by-step procedures for solving \na problem. Writing efficient algorithms is essential, as it affects the performance and scalability of a program. Debugging, or the process \nof identifying and fixing errors, is also a crucial skill that ensures programs run correctly.\n\n\tAs programs become more complex, the importance of structure and organization increases. Concepts such as functions, \nmodules, and object-oriented programming help manage code by dividing it into reusable and manageable components. Functions \nallow specific tasks to be encapsulated into blocks of code, while object-oriented programming introduces concepts like classes and \nobjects, promoting modularity and reusability. These approaches make it easier to maintain and expand large software systems.\n\n\tAnother important area of programming is data management. Programs often need to store, retrieve, and manipulate \nlarge amounts of data. This is achieved through data structures such as arrays, lists, stacks, and queues, each designed for specific purposes. \nUnderstanding how to use these structures effectively allows programmers to optimize performance and handle data more efficiently.\n\n\tIn today’s digital age, programming extends beyond traditional computers into various fields such as robotics, \ncybersecurity, game development, and artificial intelligence. The rise of the internet has also made web development a major area of \nprogramming, involving the creation of interactive websites and online services. As technology continues to evolve, programming skills \nhave become increasingly valuable across different industries.\n\n\tCollaboration and version control are also essential aspects of modern programming. Developers often work in teams, \nusing tools like Git to track changes and manage code efficiently. This collaborative approach allows multiple programmers to contribute \nto a project while maintaining consistency and organization. Communication and documentation are equally important, ensuring that \ncode can be understood and maintained by others.\n\n\tDespite its many advantages, programming also presents challenges. Learning to code requires patience, practice, and \ncontinuous learning. Errors and bugs are inevitable, but they provide opportunities for growth and improvement. As technology advances, \nprogrammers must stay updated with new languages, tools, and best practices to remain relevant in the field.\n\n\tIn conclusion, computer programming is more than just writing code—it is a powerful skill that drives innovation and \nshapes the future of technology. It combines logic, creativity, and problem-solving to create solutions that impact everyday life. Whether \ndeveloping software, analyzing data, or building intelligent systems, programming empowers individuals to turn ideas into reality and \ncontribute to the ever-evolving digital world.");
        jScrollPane1.setViewportView(jTextArea1);

        jPanel1.add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(18, 16, 880, 636));

        jLabel5.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/01012.png"))); // NOI18N
        jPanel1.add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(953, 85, 123, -1));

        lblBookTitle.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        lblBookTitle.setText("BORROW");
        lblBookTitle.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                lblBookTitleActionPerformed(evt);
            }
        });
        jPanel1.add(lblBookTitle, new org.netbeans.lib.awtextra.AbsoluteConstraints(941, 264, 135, -1));

        btn_REVIEW.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        btn_REVIEW.setText("REVIEWS");
        btn_REVIEW.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_REVIEWActionPerformed(evt);
            }
        });
        jPanel1.add(btn_REVIEW, new org.netbeans.lib.awtextra.AbsoluteConstraints(941, 298, 135, -1));

        btnmarkasread.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        btnmarkasread.setText("MARK AS READ");
        btnmarkasread.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnmarkasreadActionPerformed(evt);
            }
        });
        jPanel1.add(btnmarkasread, new org.netbeans.lib.awtextra.AbsoluteConstraints(941, 332, 135, -1));

        btnfavorites.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        btnfavorites.setText("FAVORITES");
        btnfavorites.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnfavoritesActionPerformed(evt);
            }
        });
        jPanel1.add(btnfavorites, new org.netbeans.lib.awtextra.AbsoluteConstraints(941, 366, 135, -1));

        jButton2.setText("BACK");
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });
        jPanel1.add(jButton2, new org.netbeans.lib.awtextra.AbsoluteConstraints(960, 30, -1, -1));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 1140, Short.MAX_VALUE)
            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(layout.createSequentialGroup()
                    .addGap(0, 0, Short.MAX_VALUE)
                    .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGap(0, 0, Short.MAX_VALUE)))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 680, Short.MAX_VALUE)
            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(layout.createSequentialGroup()
                    .addGap(0, 0, Short.MAX_VALUE)
                    .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGap(0, 0, Short.MAX_VALUE)))
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void lblBookTitleActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_lblBookTitleActionPerformed
       lblBookTitle.setText("BORROWED");
    lblBookTitle.setEnabled(false);
    
   
    try {
       
        java.sql.Connection conn = java.sql.DriverManager.getConnection("jdbc:mysql://localhost:3306/library_system", "root", "");
        
      
        String sql = "UPDATE books SET status = 'BORROWED' WHERE book_title = 'Computer Programming: The Language of Innovation'";
        
        java.sql.PreparedStatement pst = conn.prepareStatement(sql);
        pst.executeUpdate(); 
        
        conn.close();
    } catch (Exception e) {
      
        System.out.println("Database Update Error: " + e.getMessage());
    }
        borrow_form bf = new borrow_form(); 
    bf.txtBookTitle.setText("Computer Programming: The Language of Innovation"); 
    
  
    bf.setVisible(true);
    }//GEN-LAST:event_lblBookTitleActionPerformed

    private void btn_REVIEWActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_REVIEWActionPerformed
      String bookTitle = "Computer Programming: The Language of Innovation"; 

  
    REVIEW_BOOK rf = new REVIEW_BOOK();
    rf.lblReviewBookTitle.setText("SHARE YOUR THOUGHTS");
    rf.txtBookTitle.setText(bookTitle);
    
    rf.setVisible(true);
    }//GEN-LAST:event_btn_REVIEWActionPerformed

    private void btnmarkasreadActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnmarkasreadActionPerformed
        javax.swing.JOptionPane.showMessageDialog(this, 
        "You have successfully marked 'Computer Programming: The Language of Innovation' as Read!", 
        "Success", 
        javax.swing.JOptionPane.INFORMATION_MESSAGE);

    
    btnmarkasread.setText("COMPLETED");
    btnmarkasread.setEnabled(false);
    
    
    btnmarkasread.setBackground(new java.awt.Color(153, 255, 153)); 
    }//GEN-LAST:event_btnmarkasreadActionPerformed

    private void btnfavoritesActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnfavoritesActionPerformed
        javax.swing.JOptionPane.showMessageDialog(this, 
        "'Computer Programming: The Language of Innovation' has been added to your Favorites!", 
        "Added to Favorites", 
        javax.swing.JOptionPane.INFORMATION_MESSAGE);

    
    btnfavorites.setText("❤ FAVORITED");
    
   
    btnfavorites.setBackground(new java.awt.Color(255, 204, 204));
    btnfavorites.setEnabled(false);
    }//GEN-LAST:event_btnfavoritesActionPerformed

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
     DASHBOARD3 dashboardPage = new DASHBOARD3("1");
    dashboardPage.setVisible(true);
    
   
    this.dispose();
    }//GEN-LAST:event_jButton2ActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(BOOK5.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(BOOK5.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(BOOK5.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(BOOK5.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new BOOK5().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btn_REVIEW;
    private javax.swing.JButton btnfavorites;
    private javax.swing.JButton btnmarkasread;
    private javax.swing.JButton jButton2;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTextArea jTextArea1;
    private javax.swing.JButton lblBookTitle;
    // End of variables declaration//GEN-END:variables
}
