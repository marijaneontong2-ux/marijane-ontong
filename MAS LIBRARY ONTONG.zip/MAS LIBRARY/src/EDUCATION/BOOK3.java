package EDUCATION;
import ticaro.ui.DASHBOARD3;
import ticaro.ui.REVIEW_BOOK;
import ticaro.ui.borrow_form;

/**
 *
 * @author STUDENT
 */
public class BOOK3 extends javax.swing.JFrame {

    /**
     * Creates new form BOOK3
     */
    public BOOK3() {
        initComponents();
   checkBookStatus();
    }
    
private void checkBookStatus() {
    try {
        // 1. Connect to your database (using your 'coffee_pos' or 'library_db')
        java.sql.Connection conn = java.sql.DriverManager.getConnection("jdbc:mysql://localhost:3306/library_system", "root", "");
        
        // 2. Query to check the status of this specific book
        String sql = "SELECT status FROM books WHERE book_title = 'Media & Society: Shaping Minds in a Digital'";
        java.sql.PreparedStatement pst = conn.prepareStatement(sql);
        java.sql.ResultSet rs = pst.executeQuery();

        if (rs.next()) {
            String status = rs.getString("status");
            
            // 3. If the book is borrowed, change the button automatically
            if (status.equalsIgnoreCase("BORROWED")) {
                lblBookTitle.setText("BORROWED");
                lblBookTitle.setEnabled(false);
                lblBookTitle.setBackground(java.awt.Color.GRAY);
            } else {
                // If it was returned, it stays/becomes AVAILABLE
                lblBookTitle.setText("BORROW");
                lblBookTitle.setEnabled(true);
                lblBookTitle.setBackground(new java.awt.Color(255, 255, 255));
            }
        }
        conn.close();
    } catch (Exception e) {
        System.out.println("Error: " + e.getMessage());
    }
}
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTextArea1 = new javax.swing.JTextArea();
        jLabel5 = new javax.swing.JLabel();
        lblBookTitle = new javax.swing.JButton();
        btnREVIEWS = new javax.swing.JButton();
        btnmarkasread = new javax.swing.JButton();
        btnfavorites = new javax.swing.JButton();
        jButton2 = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setBackground(new java.awt.Color(255, 255, 255));
        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jTextArea1.setColumns(20);
        jTextArea1.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jTextArea1.setRows(5);
        jTextArea1.setText("\n\t\t\tMedia & Society: Shaping Minds in a Digital\n\t\t\t                      C. M. Veritas\n\n\tMedia has always played a powerful role in shaping society, influencing how people think, behave, and interact with the \nworld around them. From traditional forms such as newspapers, radio, and television to modern digital platforms like social media and \nonline news outlets, media serves as a primary source of information and communication. In today’s interconnected world, the relationship \nbetween media and society has become more complex, as individuals are not only consumers of content but also creators and distributors. \nThis shift has transformed the way information is produced, shared, and interpreted across cultures and communities.\n\n\tOne of the most significant functions of media is its ability to inform the public. News media provides updates on local \nand global events, helping people stay aware of political, economic, and social developments. However, the way information is presented \ncan shape public perception. Framing, language choice, and selective reporting can influence how audiences interpret events. As a result, \nmedia does not simply reflect reality it actively constructs it. This highlights the importance of media literacy, which enables individuals to \ncritically evaluate the credibility and bias of the information they encounter.\n\n\tBeyond information, media plays a central role in shaping cultural norms and values. Television shows, films, advertisements, \nand online content often portray ideas about beauty, success, relationships, and identity. These representations can reinforce stereotypes \nor challenge them, depending on how they are presented. For example, repeated exposure to certain images or narratives can influence \nhow individuals perceive themselves and others. In this way, media becomes a powerful tool for both cultural preservation and social change.\n\n\tThe rise of digital media has significantly altered the landscape of communication. Social media platforms allow users to \nconnect instantly, share experiences, and participate in global conversations. This has democratized information, giving a voice to individuals \nwho were previously unheard. Movements for social justice, political awareness, and community action have gained momentum through \nonline platforms. However, this accessibility also comes with challenges, such as the spread of misinformation, cyberbullying, and the \ncreation of echo chambers where individuals are exposed only to viewpoints that align with their own.\n\n\tAnother important aspect of media in society is its role in influencing behavior. Advertising, for instance, uses persuasive \ntechniques to shape consumer choices and lifestyle preferences. Media can also impact attitudes toward health, education, and social \nissues. Campaigns promoting public awareness such as those related to environmental protection or disease prevention demonstrate \nhow media can be used for positive change. At the same time, excessive exposure to certain types of content, such as violence or \nunrealistic standards, can have negative effects, particularly on young audiences.\n\n\tThe relationship between media and power cannot be overlooked. Media institutions often hold significant influence \nover what information is shared and how it is framed. This raises questions about ownership, control, and accountability. In some cases, \nmedia can be used to promote specific political or economic interests, shaping public opinion in subtle or direct ways. Ensuring transparency, \ndiversity of perspectives, and ethical journalism is essential in maintaining a balanced and fair media environment.\n\n\tTechnology continues to reshape the future of media and its impact on society. Innovations such as artificial intelligence, \nvirtual reality, and algorithm-driven content are changing how people consume information. Personalized feeds and recommendation \nsystems can enhance user experience but may also limit exposure to diverse viewpoints. As media evolves, individuals must adapt by \ndeveloping critical thinking skills and a responsible approach to content creation and consumption.\n\n\tIn conclusion, media and society are deeply interconnected, each influencing and shaping the other. Media serves as a \npowerful force that informs, entertains, and persuades, while also reflecting the values and dynamics of society. As the digital age \ncontinues to expand, understanding the role of media becomes increasingly important. By promoting media literacy, ethical practices, \nand responsible engagement, society can harness the power of media to foster awareness, inclusivity, and positive change.");
        jScrollPane1.setViewportView(jTextArea1);

        jPanel1.add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(18, 16, 880, 636));

        jLabel5.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/1library1..png"))); // NOI18N
        jPanel1.add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(953, 85, 123, -1));

        lblBookTitle.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        lblBookTitle.setText("BORROW");
        lblBookTitle.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                lblBookTitleActionPerformed(evt);
            }
        });
        jPanel1.add(lblBookTitle, new org.netbeans.lib.awtextra.AbsoluteConstraints(941, 261, 135, -1));

        btnREVIEWS.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        btnREVIEWS.setText("REVIEWS");
        btnREVIEWS.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnREVIEWSActionPerformed(evt);
            }
        });
        jPanel1.add(btnREVIEWS, new org.netbeans.lib.awtextra.AbsoluteConstraints(941, 295, 135, -1));

        btnmarkasread.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        btnmarkasread.setText("MARK AS READ");
        btnmarkasread.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnmarkasreadActionPerformed(evt);
            }
        });
        jPanel1.add(btnmarkasread, new org.netbeans.lib.awtextra.AbsoluteConstraints(941, 329, 135, -1));

        btnfavorites.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        btnfavorites.setText("FAVORITES");
        btnfavorites.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnfavoritesActionPerformed(evt);
            }
        });
        jPanel1.add(btnfavorites, new org.netbeans.lib.awtextra.AbsoluteConstraints(941, 363, 135, -1));

        jButton2.setText("BACK");
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });
        jPanel1.add(jButton2, new org.netbeans.lib.awtextra.AbsoluteConstraints(960, 30, -1, -1));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 1140, Short.MAX_VALUE)
            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(layout.createSequentialGroup()
                    .addGap(0, 0, Short.MAX_VALUE)
                    .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGap(0, 0, Short.MAX_VALUE)))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 680, Short.MAX_VALUE)
            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(layout.createSequentialGroup()
                    .addGap(0, 0, Short.MAX_VALUE)
                    .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGap(0, 0, Short.MAX_VALUE)))
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void lblBookTitleActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_lblBookTitleActionPerformed
    lblBookTitle.setText("BORROWED");
    lblBookTitle.setEnabled(false);
    
   
    try {
       
        java.sql.Connection conn = java.sql.DriverManager.getConnection("jdbc:mysql://localhost:3306/library_system", "root", "");
        
      
        String sql = "UPDATE books SET status = 'BORROWED' WHERE book_title = 'Media & Society: Shaping Minds in a Digital'";
        
        java.sql.PreparedStatement pst = conn.prepareStatement(sql);
        pst.executeUpdate(); 
        
        conn.close();
    } catch (Exception e) {
      
        System.out.println("Database Update Error: " + e.getMessage());
    }
        borrow_form bf = new borrow_form(); 
    bf.txtBookTitle.setText("Media & Society: Shaping Minds in a Digital"); 
    
  
    bf.setVisible(true);
    }//GEN-LAST:event_lblBookTitleActionPerformed

    private void btnREVIEWSActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnREVIEWSActionPerformed
       String bookTitle = "Media & Society: Shaping Minds in a Digital"; 

  
    REVIEW_BOOK rf = new REVIEW_BOOK();
    rf.lblReviewBookTitle.setText("SHARE YOUR THOUGHTS");
    rf.txtBookTitle.setText(bookTitle);
    
    rf.setVisible(true);
    }//GEN-LAST:event_btnREVIEWSActionPerformed

    private void btnmarkasreadActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnmarkasreadActionPerformed
       javax.swing.JOptionPane.showMessageDialog(this, 
        "You have successfully marked 'Media & Society: Shaping Minds in a Digital' as Read!", 
        "Success", 
        javax.swing.JOptionPane.INFORMATION_MESSAGE);

    
    btnmarkasread.setText("COMPLETED");
    btnmarkasread.setEnabled(false);
    
    
    btnmarkasread.setBackground(new java.awt.Color(153, 255, 153)); 
    }//GEN-LAST:event_btnmarkasreadActionPerformed

    private void btnfavoritesActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnfavoritesActionPerformed
        javax.swing.JOptionPane.showMessageDialog(this, 
        "'Media & Society: Shaping Minds in a Digital' has been added to your Favorites!", 
        "Added to Favorites", 
        javax.swing.JOptionPane.INFORMATION_MESSAGE);

    
    btnfavorites.setText("❤ FAVORITED");
    
   
    btnfavorites.setBackground(new java.awt.Color(255, 204, 204));
    btnfavorites.setEnabled(false);
    }//GEN-LAST:event_btnfavoritesActionPerformed

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
       DASHBOARD3 dashboardPage = new DASHBOARD3("1");
    dashboardPage.setVisible(true);
    
   
    this.dispose();
    }//GEN-LAST:event_jButton2ActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(BOOK3.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(BOOK3.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(BOOK3.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(BOOK3.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new BOOK3().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnREVIEWS;
    private javax.swing.JButton btnfavorites;
    private javax.swing.JButton btnmarkasread;
    private javax.swing.JButton jButton2;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTextArea jTextArea1;
    private javax.swing.JButton lblBookTitle;
    // End of variables declaration//GEN-END:variables
}
